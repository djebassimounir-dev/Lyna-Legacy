#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EMPREINTE DE CHOC PAR ENTREPRISE (étape B)                                          version 1.0
*** ANALYSE EXPLORATOIRE : elle utilise les mêmes données (2009-2024) que le test principal. ***

Question : une entreprise réagit-elle de façon PERSISTANTE à des épisodes successifs de hausse d'énergie,
au-delà de ce que ses caractéristiques observables expliquent ? (= existe-t-il une mémoire propre à l'entreprise ?)

Définitions fixées ici, avant exécution :
 1. Épisode = suite d'au moins 3 trimestres où le choc énergétique g+ (variation annuelle positive de PPIENG,
    récupérée du panel) dépasse le seuil --thr (défaut 0,10), en comblant les trous d'1 trimestre.
 2. Début de l'épisode t0 = son premier trimestre. Référence = marge moyenne sur t0-4..t0-1 (>= 2 obs.).
 3. Réponse de l'entreprise R = moyenne des écarts de marge à la référence aux trimestres t0+1..t0+4 (>= 3 obs.).
 4. Fenêtres PLACEBO : débuts t0' pris dans des périodes calmes (voir ci-dessous). Elles mesurent la persistance "ordinaire"
    (volatilité, retour à la moyenne) sans choc énergétique.
 5. STATISTIQUE PRINCIPALE : corrélation de rang (Spearman) entre la réponse RÉSIDUELLE au DERNIER épisode et la réponse résiduelle
    moyenne aux épisodes PRÉCÉDENTS. "Résiduelle" = réponses purgées (régression linéaire) des variables observables à t0-1
    (jours de stock, délai, rigidité, répercussion), de l'exposition et du code SIC à 2 chiffres (lu dans edgar_cache s'il existe).
    Inférence : IC bootstrap par entreprise et test de permutation (unilatéral, rho > 0).
 6. Statistique secondaire : la même corrélation sur les réponses brutes.
 7. DIAGNOSTIC (non décisionnel) : fenêtres placebo [t0'-4, t0'+4] sans aucun trimestre de choc (g+ < seuil), espacées de >= 9 trimestres.
    ATTENTION : elles contiennent encore la récupération après les épisodes précédents ; elles peuvent donc montrer une persistance
    élevée qui est elle-même de la mémoire de choc. La comparaison au placebo est donc biaisée contre la détection : à lire avec prudence.
Lecture : résiduelle > 0 (IC sans 0 et p_perm < 0,05) => réponse persistante propre à l'entreprise, au-delà de l'observable
          (mémoire de choc OU trait non observé de sensibilité : le test ne les distingue pas) ;
          brute > 0 mais résiduelle ~ 0 => persistance entièrement expliquée par l'observable (compatible avec lambda) ;
          les deux ~ 0 => pas de réponse persistante propre à l'entreprise dans ces données.

Usage :  python damp_fingerprints.py                  (panel_edgar.csv.gz)
         python damp_fingerprints.py --selftest hidden   (essai sur données simulées : damp | null | hidden)
Sorties dans le dossier  empreintes/  (rien n'est écrit dans resultats_edgar/).
"""
import os, sys, json, argparse, datetime
import numpy as np
import pandas as pd
from scipy import stats
import damp_edgar as D

K_STAT, K_DESC = 4, 8

def find_episodes(g, thr, min_len=3, max_gap=1):
    on = np.asarray(g >= thr, bool); T = len(on); filled = on.copy(); i = 0
    while i < T:
        if not on[i] and i > 0 and on[i-1]:
            j = i
            while j < T and not on[j]: j += 1
            if j < T and (j - i) <= max_gap: filled[i:j] = True
            i = j
        else: i += 1
    eps, i = [], 0
    while i < T:
        if filled[i]:
            j = i
            while j + 1 < T and filled[j+1]: j += 1
            if j - i + 1 >= min_len: eps.append((i, j))
            i = j + 1
        else: i += 1
    return eps

def placebo_onsets(g, thr, T, n):
    """(diagnostic) Débuts placebo : fenêtres [t0'-4, t0'+4] SANS aucun trimestre de choc (g+ < seuil), espacées d'au moins 9 trimestres,
    prises dans l'ordre chronologique (maximise leur nombre)."""
    chosen = []
    for s in range(4, T - K_STAT):
        if len(chosen) == n: break
        if g[max(s - 4, 0):s + K_STAT + 1].max() >= thr: continue
        if any(abs(s - c) < 9 for c in chosen): continue
        chosen.append(s)
    return chosen

def responses(A, t0, K=K_DESC):
    m = A["m"]; N, T = m.shape
    blk = m[:, max(t0 - 4, 0):t0]; nb = np.sum(~np.isnan(blk), axis=1)
    base = np.where(nb >= 2, np.nanmean(blk, axis=1), np.nan)
    resp = np.full((N, K), np.nan)
    for k in range(1, K + 1):
        if t0 + k < T: resp[:, k-1] = m[:, t0 + k] - base
    R = np.where(np.sum(~np.isnan(resp[:, :K_STAT]), axis=1) >= 3, np.nanmean(resp[:, :K_STAT], axis=1), np.nan)
    return resp, R

def residualize(R, X):
    ok = ~np.isnan(R) & ~np.isnan(X).any(axis=1); out = np.full_like(R, np.nan)
    if ok.sum() < 40: return out
    Xo = np.column_stack([np.ones(ok.sum()), X[ok]]); coef, *_ = np.linalg.lstsq(Xo, R[ok], rcond=None)
    out[ok] = R[ok] - Xo @ coef
    return out

def spear(a, b):
    ok = ~np.isnan(a) & ~np.isnan(b)
    return float(stats.spearmanr(a[ok], b[ok]).correlation) if ok.sum() >= 40 else float("nan")

def primary_pair(vecs):
    late = vecs[-1]; early = np.nanmean(np.vstack(vecs[:-1]), axis=0) if len(vecs) > 2 else vecs[0]
    return early, late

def load_sic2(firms, cache="edgar_cache"):
    out = np.full(len(firms), np.nan)
    for i, f in enumerate(firms):
        p = os.path.join(cache, f"sic_{int(f)}.json")
        if os.path.exists(p):
            try:
                v = json.load(open(p)).get("sic")
                if v is not None: out[i] = int(v) // 100
            except Exception: pass
    return out

def build_X(A, t0, expo, sic_dum):
    cols = [A["z_" + k][:, max(t0 - 1, 0)] for k in D.XN] + [expo]
    X = np.column_stack(cols)
    return np.column_stack([X, sic_dum]) if sic_dum.shape[1] else X

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--panel", default="panel_edgar.csv.gz"); ap.add_argument("--thr", type=float, default=0.10)
    ap.add_argument("--selftest", choices=["damp", "null", "hidden"]); ap.add_argument("--boot", type=int, default=1000)
    ap.add_argument("--out", default="empreintes")
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True)
    print("*" * 92 + "\n  ANALYSE EXPLORATOIRE : mêmes données que le test principal. À déclarer comme telle.\n" + "*" * 92)
    if a.selftest:
        D.CFG.update(INIT=40, BURN=8, START_YEAR=2005); panel = make_selftest_panel(a.selftest)
    else:
        if not os.path.exists(a.panel): sys.exit(f"{a.panel} introuvable.")
        panel = pd.read_csv(a.panel)
    if "expo" not in panel: sys.exit("Colonne 'expo' absente du panel (utiliser le panel produit par damp_edgar.py v1.3).")
    A = D.to_arrays(panel); N, T = A["N"], A["T"]
    firms = np.sort(panel["firm"].unique())
    expo = panel.groupby("firm")["expo"].first().reindex(firms).values.astype(float)
    # choc g+ : s = expo * g+  =>  g+ = s / expo (médiane sur les entreprises)
    pp = panel[panel["expo"] > 1e-9]; g = (pp["s"] / pp["expo"]).groupby(pp["q"]).median().reindex(range(T)).fillna(0.0).values
    eps = find_episodes(g, a.thr)
    print(f"\nÉpisodes détectés (seuil {a.thr}) : " + (", ".join(f"[{s}-{e}] pic {g[s:e+1].max():.2f}" for s, e in eps) or "aucun"))
    if len(eps) < 2: sys.exit("Moins de 2 épisodes : test impossible (essaie --thr plus bas).")
    plac = placebo_onsets(g, a.thr, T, len(eps))
    print("Début des épisodes :", [s for s, _ in eps], "| débuts placebo :", plac)
    if len(plac) < 2: sys.exit("Moins de 2 fenêtres placebo calmes : test impossible.")
    sic2 = load_sic2(firms); big = [c for c, n in pd.Series(sic2).value_counts().items() if n >= 8]
    sic_dum = np.column_stack([(sic2 == c).astype(float) for c in big[1:]]) if len(big) > 1 else np.zeros((N, 0))
    print(f"Contrôles : 4 variables opérationnelles, exposition" + (f", {len(big)} industries (SIC2)" if len(big) > 1 else ", (pas de SIC : cache absent)"))
    def collect(onsets):
        Rs, Rr, prof = [], [], []
        for t0 in onsets:
            resp, R = responses(A, t0); Rs.append(R); Rr.append(residualize(R, build_X(A, t0, expo, sic_dum))); prof.append(resp)
        return Rs, Rr, prof
    E_R, E_res, E_prof = collect([s for s, _ in eps]); P_R, P_res, P_prof = collect(plac)
    ne = [int(np.sum(~np.isnan(r))) for r in E_R]; print("Entreprises avec une réponse mesurable par épisode :", ne)
    pairs = {"résiduelle (PRINCIPALE)": (E_res, P_res), "brute": (E_R, P_R)}
    rng = np.random.default_rng(0); rows = []
    for nom, (Ev, Pv) in pairs.items():
        e_early, e_late = primary_pair(Ev); p_early, p_late = primary_pair(Pv)
        rE, rP = spear(e_early, e_late), spear(p_early, p_late)
        bE = np.empty(a.boot); bD = np.empty(a.boot)
        for b_ in range(a.boot):
            ix = rng.integers(0, N, N); bE[b_] = spear(e_early[ix], e_late[ix]); bD[b_] = bE[b_] - spear(p_early[ix], p_late[ix])
        lo, hi = np.nanpercentile(bE, [2.5, 97.5]); dlo, dhi = np.nanpercentile(bD, [2.5, 97.5])
        ok = ~np.isnan(e_early) & ~np.isnan(e_late); perm = np.empty(2000); x, y = e_early[ok], e_late[ok]
        for b_ in range(2000): perm[b_] = stats.spearmanr(x, rng.permutation(y)).correlation
        rows.append(dict(version=nom, n_paires=int(ok.sum()), rho_episodes=rE, IC95_bas=lo, IC95_haut=hi, p_perm=(1 + np.sum(perm >= rE)) / 2001,
                         diag_rho_placebo=rP, diag_difference=rE - rP, diag_IC_bas=dlo, diag_IC_haut=dhi))
    S = pd.DataFrame(rows); S.to_csv(os.path.join(a.out, "empreintes_stats.csv"), index=False)
    pd.set_option("display.width", 200, "display.float_format", lambda x: f"{x:.4f}")
    print("\n=== Persistance de la réponse : dernier épisode vs épisodes précédents (colonnes diag_* = diagnostic placebo, biaisé) ===\n", S.to_string(index=False))
    # paires deux à deux (descriptif)
    print("\n--- Corrélations de rang épisode i vs j (brute | résiduelle), à comparer au placebo ---")
    for i in range(len(eps)):
        for j in range(i + 1, len(eps)):
            print(f"  E{i+1} vs E{j+1}: {spear(E_R[i], E_R[j]):+.3f} | {spear(E_res[i], E_res[j]):+.3f}      placebo P{i+1} vs P{j+1}: {spear(P_R[i], P_R[j]):+.3f} | {spear(P_res[i], P_res[j]):+.3f}")
    # empreintes individuelles
    recs = []
    for e, ((s, en), resp, R) in enumerate(zip(eps, E_prof, E_R)):
        q1, q2 = np.nanpercentile(R, [33.3, 66.7])
        for i in range(N):
            if np.isnan(R[i]): continue
            r = resp[i]; depth = np.nanmin(r) if np.any(~np.isnan(r)) else np.nan
            kt = int(np.nanargmin(r)) + 1 if np.any(~np.isnan(r)) else np.nan
            rec = np.nan
            if depth < 0 and not np.isnan(kt):
                for k in range(int(kt) + 1, K_DESC + 1):
                    if not np.isnan(r[k-1]) and r[k-1] >= 0.5 * depth: rec = k; break
            typ = "absorbe" if R[i] >= q2 else ("amplifie" if R[i] <= q1 else "transmet")
            recs.append(dict(firm=int(firms[i]), episode=f"E{e+1}", debut=s, R_moy_4t=R[i], type=typ, creux=depth, trimestre_creux=kt, recup_mi_creux=rec,
                             **{f"k{k+1}": r[k] for k in range(K_DESC)}))
    pd.DataFrame(recs).to_csv(os.path.join(a.out, "empreintes_firmes.csv"), index=False)
    print("\n--- Profil moyen de réponse (écart de marge, trimestres t0+1..t0+8) par épisode ---")
    for e, resp in enumerate(E_prof): print(f"  E{e+1}: " + " ".join(f"{np.nanmean(resp[:, k]):+.3f}" for k in range(K_DESC)))
    for e, resp in enumerate(P_prof): print(f"  P{e+1} (placebo): " + " ".join(f"{np.nanmean(resp[:, k]):+.3f}" for k in range(K_DESC)))
    rs, rb = S.iloc[0], S.iloc[1]
    print(f"Résiduelle : rho = {rs.rho_episodes:+.3f}  IC95 [{rs.IC95_bas:+.3f} ; {rs.IC95_haut:+.3f}]  p_perm = {rs.p_perm:.4f}  |  brute : rho = {rb.rho_episodes:+.3f}  p_perm = {rb.p_perm:.4f}")
    if rs.IC95_bas > 0 and rs.p_perm < 0.05:
        print("-> Réponse persistante propre à l'entreprise, AU-DELÀ de l'observable (mémoire de choc ou trait non observé : non distinguables ici). À confirmer sur données indépendantes.")
    elif rb.IC95_bas > 0 and rb.p_perm < 0.05:
        print("-> Persistance présente mais EXPLIQUÉE par les variables observables : pas de preuve de mémoire propre à l'entreprise.")
    else:
        print("-> Pas de persistance de la réponse détectable : pas de preuve de mémoire stable par entreprise dans ces données.")
    json.dump(dict(horodatage=datetime.datetime.utcnow().isoformat() + "Z", seuil=a.thr, episodes=eps, placebo=plac, exploratoire=True),
              open(os.path.join(a.out, "journal.json"), "w"), default=str, indent=1)

def make_selftest_panel(world, N=500, T=88, seed=42):
    """Panel simulé avec colonne expo. 'hidden' : sensibilité cachée propre à chaque entreprise (non observable)."""
    from scipy.signal import lfilter
    rng = np.random.default_rng(seed); g = np.zeros(T); jumps = {14: .25, 30: .25, 52: .25, 66: .30}
    for t in range(1, T): g[t] = 0.8 * g[t-1] + rng.normal(0, 0.04) + jumps.get(t, 0.0)   # hausses PERSISTANTES (pas des pics isolés)
    e = rng.lognormal(-0.3, 0.5, N); hid = rng.standard_normal(N); s = e[:, None] * np.maximum(g, 0)[None, :]
    Z = {k: np.zeros((N, T)) for k in D.XN}
    for k in Z:
        Z[k][:, 0] = rng.standard_normal(N)
        for t in range(1, T): Z[k][:, t] = 0.9 * Z[k][:, t-1] + np.sqrt(1 - 0.81) * rng.standard_normal(N)
    mu = rng.normal(0.06, 0.04, N); m = np.zeros((N, T)); m[:, 0] = mu + rng.normal(0, 0.02, N)
    K = D.torsional_kernel(8, -0.5, 4.0); rho = 0.5; M = np.zeros(N); qh = np.zeros((N, 9)); sc = s[s > 0].std()
    for t in range(T - 1):
        if world == "null": pi = 0.05 * s[:, t]
        else:
            q = np.maximum(0, s[:, t] - np.maximum(0, 0.3 + 0.2 * Z["stock"][:, t]) * sc)
            qh = np.roll(qh, 1, axis=1); qh[:, 0] = q; M = rho * M + (1 - rho) * (qh @ K)
            lam = np.exp(-0.3*Z["stock"][:, t] + 0.5*Z["delay"][:, t] + 0.4*Z["rig"][:, t] - 0.4*Z["pass"][:, t])
            if world == "hidden": lam = lam * np.exp(0.8 * hid)
            pi = 0.5 * lam * M
        m[:, t+1] = m[:, t] + 0.25 * (mu - m[:, t]) - pi + rng.normal(0, 0.012, N)
    rows = [pd.DataFrame(dict(firm=np.arange(N), q=t, m=m[:, t], s=s[:, t], stock=40+15*Z["stock"][:, t], delay=45+15*Z["delay"][:, t],
            rig=0.25+0.08*Z["rig"][:, t], expo=e, **{"pass": 0.6+0.2*Z["pass"][:, t]})) for t in range(T)]
    return pd.concat(rows, ignore_index=True)

if __name__ == "__main__":
    main()
