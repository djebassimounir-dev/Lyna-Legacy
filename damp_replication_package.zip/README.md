# Replication package: a frozen-protocol test of the DAMP model, with a detectability certificate

Author: Mounir Djebassi (INAS — International Network of Algerian Scientists; ORCID 0009-0009-6871-7693; https://github.com/djebassimounir-dev)
Correspondence: djebassimounir@gmail.com

This package accompanies the paper *A Frozen-Protocol Test of the DAMP Model of Delayed Cost-Shock Transmission to Firm Margins, with a Detectability Certificate*.

## Chronology and status (read first)

The analysis protocol was frozen on 2026-11-14 at 18:46 UTC (SHA-256 fingerprints in `protocole_fige_edgar.json`) and executed once at 19:12 UTC (`resultats_edgar/journal.jsonl`, no forced re-run). The package was deposited publicly after execution, so it is a time-stamped record, **not an external pre-registration**. Analyses outside the frozen protocol are labelled exploratory or post hoc below.

## Contents

| Path | Role | Status |
|---|---|---|
| `damp_edgar.py` | Frozen analysis script (v1.3): data build, models, walk-forward, tests | Frozen protocol |
| `protocole_fige_edgar.json` | Freeze record: fingerprints of script and panel, configuration | Frozen protocol |
| `panel_edgar.csv.gz` | Analysis panel (SEC EDGAR XBRL + FRED), 1,104 U.S. manufacturing firms, 2009–2024 | Frozen protocol |
| `resultats_edgar/` | Outputs of the single frozen run (margin and rupture tests, falsification, parameters, journal) | Frozen protocol |
| `environnement.txt` | Python and library versions used | Reproducibility |
| `detectability.py` | Detectability certificate (v1.1): synthetic DAMP signal injected into the real panel | Methodological analysis |
| `certificat_detectabilite_v2/`, `certificat_detectabilite_v2_estimateur_borne/` | Certificate outputs for the frozen estimator and for a bounded exploratory variant | Methodological analysis |
| `damp_fingerprints.py`, `empreintes/` | Firm-level shock fingerprints across three energy-price episodes | Exploratory |
| `posthoc_h3.py`, `posthoc_h3/` | Re-test of the rupture hypothesis with a quarter-block bootstrap | Post hoc |
| `posthoc_complementarity.py`, `posthoc_complementarity/` | Complementarity (forecast encompassing) with a smoothing control | Post hoc, exploratory |
| `damp_v2.py`, `panel_retail.csv.gz`, `certificat_v2/` | Second (cross-sectional) protocol for wholesale and retail firms, v2.1, and its detectability certificate; the confirmatory test was **not run** because power was insufficient | Abandoned before execution |

The folder `certificat_detectabilite` from an earlier version of the certificate is **not** included: its injected signal was concentrated on a few extreme firms and its results were discarded (see the paper, Section 6).

## How to reproduce

1. Put all `.py` files in one folder together with the panel files. Python 3 with `numpy`, `pandas`, `scipy`, `scikit-learn` and `requests` (versions in `environnement.txt`).
2. Verify fingerprints: the SHA-256 of `damp_edgar.py` and `panel_edgar.csv.gz` must equal the values in `protocole_fige_edgar.json`.
3. The frozen test refuses to run if the fingerprints differ, or if results already exist. To rebuild the panel from public sources, create `sec_user_agent.txt` with your name and e-mail (required by the SEC) and run `python damp_edgar.py data`; restated filings may change values slightly, so use the deposited panel for exact reproduction.
4. Post hoc scripts recompute the predictions with the frozen code (AUCs reproduce exactly) and write only to their own folders.

## Data sources

SEC EDGAR XBRL "frames" API (company financial statements) and FRED (producer price index for fuels and power, series PPIENG). Both are public.

## Use of AI tools

Code and drafts were developed with the assistance of an AI model (Claude, Anthropic) under the author's direction; the author reviewed and executed all analyses and is responsible for the content.

## License

Text and data: CC BY 4.0. Code: MIT License.
