#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
*** ANALYSE POST HOC (non préenregistrée) ***                                       version 1.0

Objet : ré-évaluer le test de RUPTURE (H3 : AUC de DAMP vs autres modèles) avec un bootstrap par BLOCS DE TRIMESTRES.
Raison : le test d'origine rééchantillonne les ENTREPRISES. Or les entreprises d'un même trimestre subissent les mêmes chocs
(énergie, conjoncture) : leurs erreurs sont corrélées dans le temps. Un bootstrap par entreprise ignore cette corrélation
commune et donne des intervalles trop étroits (p-values trop optimistes). Ici on rééchantillonne des blocs de trimestres
consécutifs (longueur 4 = horizon de la cible, qui recouvre 4 trimestres).

Le script RECALCULE les prévisions (walk-forward identique au test gelé, environ 8 à 10 minutes) car celles-ci n'ont pas été
enregistrées ; il vérifie qu'il retrouve les mêmes AUC que ton test d'origine (resultats_edgar/principal_auc.csv).
Il n'écrit RIEN dans resultats_edgar/ : sorties dans posthoc_h3/.

Usage :  python posthoc_h3.py            (panel_edgar.csv.gz ; compter 10 à 15 minutes)
         python posthoc_h3.py --synthetic   (essai technique sur données simulées)
"""
import os, sys, time, argparse, datetime
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score
import damp_edgar as D

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--panel", default="panel_edgar.csv.gz"); ap.add_argument("--synthetic", action="store_true")
    ap.add_argument("--boot", type=int, default=1000); ap.add_argument("--block", type=int, default=4)
    ap.add_argument("--out", default="posthoc_h3"); ap.add_argument("--old", default="resultats_edgar")
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True)
    print("*" * 92 + "\n  ANALYSE POST HOC : non préenregistrée. À déclarer comme telle dans le papier.\n" + "*" * 92)
    if a.synthetic:
        D.CFG.update(INIT=40, BURN=8, START_YEAR=2005); panel = D.simulate_panel(300, 88, "damp", 42)
    else:
        if not os.path.exists(a.panel): sys.exit(f"{a.panel} introuvable : lance ce script dans le dossier de damp_edgar.py.")
        panel = pd.read_csv(a.panel)
    A = D.to_arrays(panel); t0 = time.time()
    print("Recalcul des prévisions (walk-forward, 9 modèles)...", flush=True)
    preds, probs, plog, y, R = D.walk_forward_panel(A, D.ALL_MODELS, verbose=False)
    print(f"  terminé en {time.time()-t0:.0f}s")
    models = list(D.ALL_MODELS); ref = "DAMP"
    E2 = A["obs"] & ~np.isnan(R)
    for m in models: E2 &= ~np.isnan(probs[m])
    r = R[E2]; fi, qi = np.where(E2); qs = np.unique(qi); nq = len(qs); qpos = np.searchsorted(qs, qi)
    print(f"Observations de rupture : {len(r)} | événements : {int(r.sum())} | trimestres d'origine : {nq} ({qs.min()} à {qs.max()})")
    auc = {m: roc_auc_score(r, probs[m][E2]) for m in models}
    # --- reproduction du test d'origine ---
    f_old = os.path.join(a.old, "principal_auc.csv")
    if os.path.exists(f_old) and not a.synthetic:
        old = pd.read_csv(f_old).set_index("modèle")["AUC"]; dmax = max(abs(auc[m] - old[m]) for m in models if m in old.index)
        print(f"Reproduction de l'AUC d'origine : écart maximal = {dmax:.2e}  " + ("(identique)" if dmax < 1e-6 else "(ATTENTION : différent : ne pas interpréter sans vérifier)"))
    # --- bootstrap par blocs de trimestres ---
    rng = np.random.default_rng(0); B, L = a.boot, a.block
    boot = {m: np.full(B, np.nan) for m in models}
    for b in range(B):
        seq = []
        while len(seq) < nq:
            st = int(rng.integers(0, nq)); seq.extend([(st + j) % nq for j in range(L)])   # blocs circulaires de L trimestres
        cnt = np.bincount(np.array(seq[:nq]), minlength=nq).astype(float); w = cnt[qpos]
        rp = r[w > 0]
        if rp.sum() < 2 or rp.sum() == len(rp): continue
        for m in models: boot[m][b] = roc_auc_score(r, probs[m][E2], sample_weight=w)
    rows = []
    for m in [x for x in models if x != ref]:
        d = boot[ref] - boot[m]; d = d[~np.isnan(d)]
        lo, hi = np.percentile(d, [2.5, 97.5]); p = min(1.0, 2 * min((d <= 0).mean(), (d >= 0).mean()) + 1 / len(d))
        rows.append(dict(DAMP_vs=m, dAUC=auc[ref] - auc[m], IC_bas=lo, IC_haut=hi, p=p))
    T = pd.DataFrame(rows); T["p_Holm"] = D.holm(T["p"].values)
    T["verdict_blocs_trimestres"] = np.where(T["p_Holm"] < .05, np.where(T["dAUC"] > 0, "DAMP meilleur", "DAMP moins bon"), "pas de différence")
    f_t = os.path.join(a.old, "principal_tests_rupture.csv")
    if os.path.exists(f_t) and not a.synthetic:
        o = pd.read_csv(f_t)[["DAMP_vs", "p_Holm", "verdict"]].rename(columns={"p_Holm": "p_Holm_ancien_par_entreprise", "verdict": "verdict_ancien"})
        T = T.merge(o, on="DAMP_vs", how="left")
    pd.set_option("display.width", 220, "display.float_format", lambda x: f"{x:.4f}")
    print("\n=== H3 re-testée : AUC de DAMP vs autres modèles, bootstrap par BLOCS DE TRIMESTRES (post hoc) ===\n", T.to_string(index=False))
    T.to_csv(os.path.join(a.out, "h3_posthoc_blocs_trimestres.csv"), index=False)
    with open(os.path.join(a.out, "journal.txt"), "w", encoding="utf-8") as f:
        f.write(f"POST HOC, non préenregistré. {datetime.datetime.utcnow().isoformat()}Z ; blocs de {L} trimestres ; {B} tirages ; {nq} trimestres.\n")
    m2 = T[T["DAMP_vs"] == "M2"].iloc[0]
    print("\n=== LECTURE ===")
    print(f"H3 (DAMP vs M2) : dAUC = {m2.dAUC:+.4f}, IC95 [{m2.IC_bas:+.4f} ; {m2.IC_haut:+.4f}], p corrigé (Holm) = {m2.p_Holm:.4f}.")
    if m2.p_Holm < 0.05 and m2.dAUC > 0: print("-> H3 résiste à la correction : l'avantage de DAMP sur M2 reste significatif en tenant compte des chocs communs aux trimestres.")
    elif m2.dAUC > 0: print("-> H3 ne résiste PAS : l'avantage apparent (dAUC > 0) n'est plus significatif quand on tient compte des chocs communs aux trimestres : les intervalles du test d'origine étaient trop étroits. À écrire tel quel dans le papier (résultat post hoc).")
    else: print("-> Pas d'avantage de DAMP sur M2 pour détecter les ruptures.")
    print(f"Sorties : {a.out}/")

if __name__ == "__main__":
    main()
