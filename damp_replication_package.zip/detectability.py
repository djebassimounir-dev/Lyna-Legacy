#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CERTIFICAT DE DÉTECTABILITÉ (étape A)                                              version 1.1 (injection bornée : le signal n'est plus concentré sur quelques entreprises extrêmes)

Question : si un effet DAMP d'une intensité donnée existait vraiment dans ce panel, le protocole gelé
(damp_edgar.py : mêmes modèles, même walk-forward, mêmes tests) le détecterait-il ?

Méthode : on garde la STRUCTURE RÉELLE du panel (mêmes entreprises, mêmes trous, mêmes chocs énergétiques,
mêmes variables opérationnelles, mêmes marges réelles = le vrai bruit) et on y INJECTE un signal DAMP synthétique
(vraie structure, paramètres connus) d'intensité kappa croissante. Chaque réplication ré-échantillonne les
entreprises (bootstrap par entreprise). On mesure la fréquence de détection (puissance).

kappa = écart-type du signal injecté (variation de marge à 4 trimestres) / écart-type observé de cette variation.

Usage (dans le dossier de damp_edgar.py ; ce script n'écrit RIEN dans resultats_edgar/) :
  python detectability.py --quick           essai technique (3 intensités x 3 réplications, ~5 min)
  python detectability.py                   run complet (6 intensités x 10 réplications ; compter 1,5 à 3 h sur le vrai panel)
  python detectability.py --summary         ré-affiche le certificat à partir des résultats déjà calculés
Le run est REPRENABLE : si tu l'interromps, relance la même commande, il continue où il s'est arrêté.
"""
import os, sys, json, time, argparse, datetime
import numpy as np
import pandas as pd
from scipy.signal import lfilter
import damp_edgar as D

THETA_STAR = [0.5, 0.3, 0.2, -0.3, 0.5, 0.4, -0.4]   # rho, a0, a1, b_stock, b_delay, b_rig, b_pass (vrai DAMP injecté)
PHI = 0.75                                           # vitesse de récupération du déficit de marge injecté
MODELS = ["M0", "M2", "DAMP"]
INJ_BOUNDED = True     # injection plausible : lambda borné (sinon quelques entreprises extrêmes portent tout le signal)
INJ_Z_CLIP, INJ_EXP_CLIP = 3.0, 1.5

def damp_F_bounded(A, theta, flags, scale):
    """Variante exploratoire de l'estimateur DAMP : variables standardisées bornées à +-3 et exposant de lambda borné à +-2."""
    rho, a0, a1, bs, bd, br, bp = theta
    Z = {k: np.clip(np.nan_to_num(A["z_" + k]), -3, 3) for k in D.XN}
    absorb = np.maximum(0.0, a0 + a1 * Z["stock"]) * scale if flags["absorb"] else 0.0
    q = np.maximum(0.0, A["s0"] - absorb)
    lam = np.exp(np.clip(bs*Z["stock"] + bd*Z["delay"] + br*Z["rig"] + bp*Z["pass"], -2, 2)) if flags["lam"] else 1.0
    if not flags["mem"]: rho, Lk = 0.0, 0
    else: Lk = D.CFG["L"]
    K = D.torsional_kernel(Lk, flags["a"], D.CFG["TAU"])
    M = lfilter([1 - rho], [1.0, -rho], D.sconv(q, K), axis=1); Msum, Mprev = M.copy(), M
    for k in range(1, D.CFG["H"]):
        Kk = K[k:]; d = D.sconv(q, Kk) if len(Kk) > 0 else 0.0
        Mk = rho * Mprev + (1 - rho) * d; Msum += Mk; Mprev = Mk
    return lam * Msum

def simulate_noise_panel(N=300, T=88, seed=42):
    """Panel d'essai SANS aucun effet des chocs sur les marges (bruit + retour à la moyenne) : point zéro propre."""
    base = D.simulate_panel(N, T, "null", seed); rng = np.random.default_rng(seed + 7)
    m = np.zeros((N, T)); mu = rng.normal(0.06, 0.04, N); m[:, 0] = mu + rng.normal(0, 0.02, N)
    for t in range(T - 1): m[:, t+1] = m[:, t] + 0.25 * (mu - m[:, t]) + rng.normal(0, 0.012, N)
    base = base.sort_values(["q", "firm"]).reset_index(drop=True); base["m"] = m.T.reshape(-1)
    return base

def injected_pressure(A):
    rho, a0, a1, bs, bd, br, bp = THETA_STAR
    Z = {k: np.nan_to_num(A["z_" + k]) for k in D.XN}
    if INJ_BOUNDED: Z = {k: np.clip(v, -INJ_Z_CLIP, INJ_Z_CLIP) for k, v in Z.items()}
    ec = INJ_EXP_CLIP if INJ_BOUNDED else 5.0
    pos = A["s0"][A["s0"] > 0]; scale = pos.std() if len(pos) > 5 else 1.0
    q = np.maximum(0.0, A["s0"] - np.maximum(0.0, a0 + a1 * Z["stock"]) * scale)
    lam = np.exp(np.clip(bs*Z["stock"] + bd*Z["delay"] + br*Z["rig"] + bp*Z["pass"], -ec, ec))
    K = D.torsional_kernel(D.CFG["L"], D.CFG["A_TORSION"], D.CFG["TAU"])
    return lam * lfilter([1 - rho], [1.0, -rho], D.sconv(q, K), axis=1)

def build_signal(A):
    """Déficit de marge injecté delta (N,T) et facteurs d'échelle."""
    Pi = injected_pressure(A); pp = Pi[Pi > 0]
    Pn = Pi / (pp.std() if len(pp) > 5 else 1.0)
    Pl = np.zeros_like(Pn); Pl[:, 1:] = Pn[:, :-1]            # la pression de t agit sur la marge de t+1 (B_{t+1} = B_t + G - Pi_t)
    delta = lfilter([1.0], [1.0, -PHI], -Pl, axis=1)
    H = D.CFG["H"]
    y_real, _ = D.make_targets(A); ok = ~np.isnan(y_real)
    d4 = np.full_like(delta, np.nan); d4[:, :-H] = delta[:, H:] - delta[:, :-H]
    sd_y = np.nanstd(y_real); sd_d4 = np.nanstd(d4[ok & ~np.isnan(d4)])
    # part du signal injecté prévisible par le VRAI DAMP (le futur choc n'est pas connu à l'origine)
    F = D.damp_F(A, THETA_STAR, dict(lam=True, mem=True, absorb=True, a=D.CFG["A_TORSION"]),
                 (A["s0"][A["s0"] > 0].std() if (A["s0"] > 0).sum() > 5 else 1.0))
    mk = ok & ~np.isnan(d4)
    share = float(np.corrcoef(d4[mk], -F[mk])[0, 1] ** 2) if mk.sum() > 50 else float("nan")
    return delta, sd_y, sd_d4, share

def inject(A, delta, c):
    B = dict(A); m = A["m"].copy(); ok = ~np.isnan(m)
    m[ok] = np.clip(m[ok] + c * delta[ok], -0.5, 0.5); B["m"] = m
    return B

def compare(A, preds, y, a, b):
    E = A["obs"] & ~np.isnan(y)
    for m in (a, b): E &= ~np.isnan(preds[m])
    fi, qi = np.where(E)
    d = (y[E] - preds[a][E]) ** 2 - (y[E] - preds[b][E]) ** 2
    stat, p = D.dm_test(pd.Series(d).groupby(qi).mean().values, D.CFG["H"])
    return float(d.mean()), float(stat), float(p)

def rmse_ratio(A, preds, y, a, b):
    E = A["obs"] & ~np.isnan(y)
    for m in (a, b): E &= ~np.isnan(preds[m])
    return float(np.sqrt(np.mean((y[E] - preds[a][E]) ** 2)) / np.sqrt(np.mean((y[E] - preds[b][E]) ** 2)))

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k / n; den = 1 + z*z/n; c = (p + z*z/(2*n)) / den
    h = z * np.sqrt(p*(1-p)/n + z*z/(4*n*n)) / den
    return (max(0.0, c - h), min(1.0, c + h))

def kmin(kappas, power, level=0.8):
    for i, (k, p) in enumerate(zip(kappas, power)):
        if p >= level:
            if i == 0: return k
            k0, p0 = kappas[i-1], power[i-1]
            return k0 + (level - p0) * (k - k0) / max(p - p0, 1e-9)
    return float("nan")

def summarize(runs, out):
    g = runs.groupby("kappa")
    rows = []
    for k, d in g:
        n = len(d); dm0 = int(d["detect_M0"].sum()); dm2 = int(d["detect_M2"].sum())
        l0, h0 = wilson(dm0, n); l2, h2 = wilson(dm2, n)
        rows.append(dict(kappa=k, reps=n, puissance_vs_M0=dm0 / n, M0_bas=l0, M0_haut=h0, puissance_vs_M2=dm2 / n, M2_bas=l2, M2_haut=h2,
                         part_signal_previsible=d["share_pred"].mean(), rmse_DAMP_sur_M0=d["rmse_DAMP_sur_M0"].mean() if "rmse_DAMP_sur_M0" in d else float("nan")))
    T = pd.DataFrame(rows).sort_values("kappa").reset_index(drop=True)
    ks = T["kappa"].values
    km0, km2 = kmin(ks, T["puissance_vs_M0"].values), kmin(ks, T["puissance_vs_M2"].values)
    sh = T["part_signal_previsible"].mean()
    T.to_csv(os.path.join(out, "certificat_detectabilite.csv"), index=False)
    fa0 = T.loc[T["kappa"] == 0, "puissance_vs_M0"]; fa2 = T.loc[T["kappa"] == 0, "puissance_vs_M2"]
    print("\n" + "=" * 92 + "\nCERTIFICAT DE DÉTECTABILITÉ\n" + "=" * 92)
    pd.set_option("display.width", 170, "display.float_format", lambda x: f"{x:.3f}")
    print(T.to_string(index=False))
    print(f"\nPuissance = part des réplications où DAMP est significativement MEILLEUR (DM-HLN, p < 0,05, non corrigé par Holm).")
    print(f"kappa = 0 : taux de faux positifs  vs M0 = {float(fa0.iloc[0]) if len(fa0) else float('nan'):.3f} | vs M2 = {float(fa2.iloc[0]) if len(fa2) else float('nan'):.3f}  (attendu ~0,025 : test unilatéral implicite)")
    if len(fa2) and float(fa2.iloc[0]) > 0.15: print("ALERTE : taux de faux positifs élevé à kappa = 0 : le test n'est pas calibré sur ce panel ; ne pas interpréter la puissance.")
    print(f"Note : à kappa = 0, 'DAMP > M0' peut être positif si les chocs ont un VRAI effet linéaire dans le panel ; la référence propre du faux positif est 'DAMP > M2'.")
    print(f"Effet minimal détectable à 80 % de puissance :  DAMP > M0 : kappa >= {km0:.2f}   |   DAMP > M2 : kappa >= {km2:.2f}")
    print(f"Part du signal injecté prévisible même avec le VRAI DAMP : {sh:.0%}  (le choc futur n'est pas connu à l'origine)")
    txt = f"""DETECTABILITY CERTIFICATE (step A)
Generated: {datetime.datetime.utcnow().isoformat()}Z

Design. The real panel structure (firms, missing-data mask, real energy-shock series, real operating variables, real margins as noise) is kept,
and a synthetic DAMP signal with known structure and parameters is injected into the margins at increasing intensity kappa
(kappa = SD of the injected 4-quarter margin change / SD of the observed 4-quarter margin change). Each replication resamples firms.
The frozen protocol (damp_edgar.py: same models, walk-forward and Diebold-Mariano tests) is then applied.

Result. Minimum detectable effect at 80% power: kappa >= {km0:.2f} for DAMP better than M0, kappa >= {km2:.2f} for DAMP better than M2.
Share of the injected signal predictable even by the true DAMP: {sh:.0%}. False-positive rate at kappa = 0: vs M0 {float(fa0.iloc[0]) if len(fa0) else float('nan'):.3f}, vs M2 {float(fa2.iloc[0]) if len(fa2) else float('nan'):.3f}.

Caveats. (1) The injected model is correctly specified with known parameters, so these powers are UPPER BOUNDS for a real DAMP whose parameters must be estimated.
(2) p-values are not Holm-adjusted here. (3) Only the margin-change test (H1-type) is assessed, not the rupture AUC test. (4) The injection uses a fixed recovery rate (phi={PHI}).
If an effect smaller than the minimum detectable effect is economically plausible, a null result in the protocol cannot rule it out.
"""
    open(os.path.join(out, "detectability_certificate_EN.txt"), "w", encoding="utf-8").write(txt)
    try:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(6.5, 4))
        ax.plot(T["kappa"], T["puissance_vs_M0"], "o-", label="DAMP vs M0"); ax.plot(T["kappa"], T["puissance_vs_M2"], "s-", label="DAMP vs M2")
        ax.axhline(0.8, ls="--", c="grey"); ax.set_xlabel("kappa (intensité du signal DAMP)"); ax.set_ylabel("puissance"); ax.set_ylim(0, 1.02); ax.legend(); ax.grid(alpha=.3)
        fig.tight_layout(); fig.savefig(os.path.join(out, "certificat_detectabilite.png"), dpi=150)
    except Exception as e:
        print("(graphique non produit :", type(e).__name__, ")")
    print(f"\nFichiers : {out}/certificat_detectabilite.csv, detectability_certificate_EN.txt, certificat_detectabilite.png")

def main():
    ap = argparse.ArgumentParser(description="Certificat de détectabilité")
    ap.add_argument("--panel", default="panel_edgar.csv.gz"); ap.add_argument("--synthetic", action="store_true")
    ap.add_argument("--reps", type=int, default=10); ap.add_argument("--kappas", default="0,0.3,0.6,1.0,1.5,2.0")
    ap.add_argument("--quick", action="store_true"); ap.add_argument("--summary", action="store_true")
    ap.add_argument("--out", default=None)
    ap.add_argument("--unbounded-injection", action="store_true", help="ancien comportement (signal concentré sur les entreprises extrêmes), pour comparaison")
    ap.add_argument("--bounded-estimator", action="store_true", help="variante exploratoire de DAMP (z et lambda bornés) à la place de l'estimateur du protocole gelé")
    a = ap.parse_args()
    global INJ_BOUNDED
    INJ_BOUNDED = not a.unbounded_injection
    if a.bounded_estimator: D.damp_F = damp_F_bounded
    if a.out is None: a.out = "certificat_detectabilite_v2" + ("_estimateur_borne" if a.bounded_estimator else "") + ("_ancienne_injection" if a.unbounded_injection else "")
    if a.quick: a.reps, a.kappas = 3, "0,1,2"
    kappas = [float(x) for x in a.kappas.split(",")]
    os.makedirs(a.out, exist_ok=True); runs_f = os.path.join(a.out, "detect_runs.csv")
    runs = pd.read_csv(runs_f) if os.path.exists(runs_f) else pd.DataFrame()
    if a.summary:
        if runs.empty: sys.exit("Aucun résultat : lance d'abord le run."); 
        return summarize(runs, a.out)
    if a.synthetic:
        D.CFG.update(INIT=40, BURN=8, START_YEAR=2005); panel = simulate_noise_panel(300, 88, 42)
    else:
        if not os.path.exists(a.panel): sys.exit(f"{a.panel} introuvable : lance ce script dans le dossier de damp_edgar.py.")
        panel = pd.read_csv(a.panel)
    print(f"Injection : {'bornée (plausible)' if INJ_BOUNDED else 'NON bornée (ancienne)'} | estimateur : {'borné (variante exploratoire)' if a.bounded_estimator else 'protocole gelé'} | dossier : {a.out}")
    print(f"Panel : {panel['firm'].nunique()} entreprises | origines de test à partir de t={D.CFG['INIT']+1} | intensités {kappas} x {a.reps} réplications")
    groups = {f: g for f, g in panel.groupby("firm")}; ids = np.array(list(groups))
    done = set((round(float(r.kappa), 4), int(r.rep)) for r in runs.itertuples()) if not runs.empty else set()
    t_start = time.time()
    for rep in range(a.reps):
        todo = [k for k in kappas if (round(k, 4), rep) not in done]
        if not todo: continue
        rng = np.random.default_rng(1000 + rep)
        draw = rng.choice(ids, size=len(ids), replace=True)
        panel_r = pd.concat([groups[f].assign(firm=i) for i, f in enumerate(draw)], ignore_index=True)
        A = D.to_arrays(panel_r)
        delta, sd_y, sd_d4, share = build_signal(A)
        for kappa in todo:
            t0 = time.time(); c = kappa * sd_y / max(sd_d4, 1e-12)
            B = inject(A, delta, c)
            preds, _, _, y, _ = D.walk_forward_panel(B, MODELS, verbose=False)
            d0, s0, p0 = compare(B, preds, y, "DAMP", "M0"); d2, s2, p2 = compare(B, preds, y, "DAMP", "M2")
            row = dict(kappa=kappa, rep=rep, c=c, share_pred=share, dMSE_vs_M0=d0, p_vs_M0=p0, dMSE_vs_M2=d2, p_vs_M2=p2,
                       detect_M0=int(p0 < 0.05 and d0 < 0), detect_M2=int(p2 < 0.05 and d2 < 0),
                       rmse_DAMP_sur_M0=rmse_ratio(B, preds, y, 'DAMP', 'M0'))
            runs = pd.concat([runs, pd.DataFrame([row])], ignore_index=True); runs.to_csv(runs_f, index=False)
            print(f"  rep {rep+1}/{a.reps} kappa={kappa:<5} détecte M0={row['detect_M0']} M2={row['detect_M2']}  ({time.time()-t0:.0f}s ; total {(time.time()-t_start)/60:.0f} min)", flush=True)
    summarize(runs, a.out)

if __name__ == "__main__":
    main()