#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
*** ANALYSE POST HOC / EXPLORATOIRE (non préenregistrée) ***                      version 1.0

DAMP est conçu comme une lentille COMPLÉMENTAIRE : voir ce que les autres modèles ne voient pas (angles morts), pas les remplacer.
Les tests H1/H2 du protocole gelé mesuraient la précision relative. Ce script teste la COMPLÉMENTARITÉ.

1) ENGLOBEMENT des prévisions de marge (Harvey, Leybourne et Newbold). Pour un modèle de base B :  e = y - prévision_B ;  d = prévision_DAMP - prévision_B.
   On régresse e sur d (sans constante) : beta > 0 => DAMP ajoute de l'information à B (beta = 1 : DAMP englobe B ; beta = 0 : B englobe DAMP).
   Test : moyenne trimestrielle de e*d, variance HAC (4 retards), correction HLN. On rapporte aussi le gain hors échantillon d'une combinaison
   B + beta*d (beta estimé en retirant le trimestre évalué : "leave-one-quarter-out"), avec son test.
   Bases : M0 (retour à la moyenne), M2 (régression avec interactions), M3_GB (boosting).
2) ANGLES MORTS, définis à l'avance (3 régimes) : tous les cas ; les 10 % de cas où B se trompe le plus (en valeur absolue) ; les trimestres d'origine
   situés dans un épisode de hausse d'énergie (seuil 0,10, comme damp_fingerprints.py).
   Famille de 9 tests (3 bases x 3 régimes), correction de Holm.
   VERDICT STRICT : englobement significatif ET gain de combinaison hors échantillon significatif (Holm). Raison : un test d'englobement récompense aussi
   une prévision moins bruitée ; en monde simulé SANS effet, l'englobement seul concluait à tort contre le boosting (qui sur-apprend).
3) RUPTURES : DAMP améliore-t-il l'AUC d'une régression logistique qui contient déjà le score de B ? (leave-one-quarter-out ; IC et p par bootstrap de blocs
   de 4 trimestres). Famille de 3 tests, Holm.
Le script recalcule les prévisions (walk-forward identique au protocole gelé ; environ 5 à 8 minutes), vérifie qu'il retrouve les AUC d'origine,
et n'écrit rien dans resultats_edgar/ (sorties : posthoc_complementarity/).
Usage :  python posthoc_complementarity.py            |    python posthoc_complementarity.py --synthetic   (essai technique)
"""
import os, sys, time, argparse, datetime
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
import damp_edgar as D
import damp_fingerprints as FP

MODELS = ["M0", "M1", "M2", "M3_GB", "DAMP"]; BASES = ["M0", "M2", "M3_GB"]; H = D.CFG["H"]

def shock_quarters(panel, T, thr):
    if "expo" in panel:
        pp = panel[panel["expo"] > 1e-9]; g = (pp["s"] / pp["expo"]).groupby(pp["q"]).median().reindex(range(T)).fillna(0.0).values
    else:
        g = panel.groupby("q")["s"].median().reindex(range(T)).fillna(0.0).values; g = g / max(g.max(), 1e-12); thr = 0.3
    eps = FP.find_episodes(g, thr); m = np.zeros(T, bool)
    for s, e in eps: m[s:e + 1] = True
    return m, eps

def encompass(E, y, pred, base, regime, minN):
    """Retourne beta, p (DAMP ajoute à base), gain hors-échantillon de la combinaison et p, pour un régime (masque N x T)."""
    cols = [t for t in range(E.shape[1]) if (E & regime)[:, t].sum() >= minN]
    if len(cols) < 8: return None
    S_ed, S_dd, S_ee, n_ = [], [], [], []
    for t in cols:
        r = E[:, t] & regime[:, t]; e = y[r, t] - pred[base][r, t]; d = pred["DAMP"][r, t] - pred[base][r, t]
        S_ed.append(np.sum(e * d)); S_dd.append(np.sum(d * d)); S_ee.append(np.sum(e * e)); n_.append(r.sum())
    S_ed, S_dd, S_ee, n_ = map(np.array, (S_ed, S_dd, S_ee, n_))
    m_t = S_ed / n_; stat, p = D.dm_test(-m_t, H)                    # H0 : DAMP n'ajoute rien ; stat < 0 => DAMP ajoute
    beta = S_ed.sum() / max(S_dd.sum(), 1e-18)
    # combinaison hors échantillon (leave-one-quarter-out)
    mse_b, mse_c = [], []
    for i in range(len(cols)):
        b_i = (S_ed.sum() - S_ed[i]) / max(S_dd.sum() - S_dd[i], 1e-18)
        mse_b.append(S_ee[i] / n_[i]); mse_c.append((S_ee[i] - 2 * b_i * S_ed[i] + b_i ** 2 * S_dd[i]) / n_[i])
    mse_b, mse_c = np.array(mse_b), np.array(mse_c); s2, p2 = D.dm_test(mse_c - mse_b, H)
    return dict(beta=float(beta), stat=float(stat), p=float(p), gain_pct=100 * (1 - mse_c.sum() / mse_b.sum()), p_combo=float(p2), trimestres=len(cols), lignes=int(n_.sum()))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--panel", default="panel_edgar.csv.gz"); ap.add_argument("--synthetic", action="store_true")
    ap.add_argument("--world", default="damp", choices=["damp", "noise"]); ap.add_argument("--boot", type=int, default=1000); ap.add_argument("--out", default="posthoc_complementarity"); ap.add_argument("--old", default="resultats_edgar")
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True)
    print("*" * 92 + "\n  ANALYSE POST HOC / EXPLORATOIRE : non préenregistrée. À déclarer comme telle.\n" + "*" * 92)
    if a.synthetic:
        D.CFG.update(INIT=40, BURN=8, START_YEAR=2005)
        if a.world == "noise":
            import detectability as DET; panel = DET.simulate_noise_panel(300, 88, 42)      # monde SANS effet des chocs : contrôle des faux positifs
        else: panel = D.simulate_panel(300, 88, "damp", 42)
    else:
        if not os.path.exists(a.panel): sys.exit(f"{a.panel} introuvable.")
        panel = pd.read_csv(a.panel)
    A = D.to_arrays(panel); T = A["T"]; t0 = time.time(); print("Recalcul des prévisions (5 modèles)...", flush=True)
    preds, probs, plog, y, R = D.walk_forward_panel(A, MODELS, verbose=False); print(f"  terminé en {time.time()-t0:.0f}s")
    E = A["obs"] & ~np.isnan(y)
    for m in MODELS: E &= ~np.isnan(preds[m])
    E2 = A["obs"] & ~np.isnan(R)
    for m in MODELS: E2 &= ~np.isnan(probs[m])
    f_old = os.path.join(a.old, "principal_auc.csv")
    if os.path.exists(f_old) and not a.synthetic:
        old = pd.read_csv(f_old).set_index("modèle")["AUC"]
        dmax = max(abs(roc_auc_score(R[E2], probs[m][E2]) - old[m]) for m in MODELS if m in old.index)
        print(f"Reproduction des AUC d'origine : écart maximal = {dmax:.2e}  " + ("(identique)" if dmax < 1e-6 else "(ATTENTION : différent)"))
    sq, eps = shock_quarters(panel, T, 0.10); print("Épisodes d'énergie :", eps)
    def make_regimes(base):
        eB = np.where(E, y - preds[base], np.nan); thr = np.nanpercentile(np.abs(eB[E]), 90)
        return {"tous les cas": (np.ones_like(E), 30), "pires 10 % de B": (np.abs(np.nan_to_num(eB)) >= thr, 8), "trimestres d'épisode d'énergie": (np.tile(sq[None, :], (A["N"], 1)), 30)}
    # ---------------- 1-2) englobement des prévisions de marge ----------------
    rows = []
    for base in BASES:
        regimes = make_regimes(base)
        for rn, (rm, mn) in regimes.items():
            res = encompass(E, y, preds, base, rm, mn)
            if res: rows.append(dict(base=base, regime=rn, **res))
    M = pd.DataFrame(rows); M["p_Holm"] = D.holm(M["p"].values); M["p_combo_Holm"] = D.holm(M["p_combo"].values)
    # un test d'englobement récompense aussi une prévision MOINS BRUITÉE (elle "ajoute" à une base qui sur-apprend) : on exige donc AUSSI un gain
    # de combinaison hors échantillon significatif
    M["verdict"] = np.where((M["p_Holm"] < .05) & (M["beta"] > 0) & (M["p_combo_Holm"] < .05) & (M["gain_pct"] > 0), "DAMP ajoute de l'information", "pas de preuve")
    pd.set_option("display.width", 220, "display.float_format", lambda x: f"{x:.4f}")
    print("\n=== Englobement de la marge : DAMP ajoute-t-il à la base ? (beta > 0 et p_Holm < 0,05) ===\n", M.to_string(index=False))
    M.to_csv(os.path.join(a.out, "englobement_marge.csv"), index=False)
    # ---------------- 3) ruptures : AUC incrémental ----------------
    fi, qi = np.where(E2); r = R[E2]; qs = np.unique(qi); nq = len(qs); qpos = np.searchsorted(qs, qi)
    sc = {m: -(np.nan_to_num(A["m"][E2]) + preds[m][E2]) for m in MODELS}
    def loqo(cols_fn):
        p = np.empty(len(r))
        for t in qs:
            te = qi == t; tr = ~te; X = cols_fn(); lr = LogisticRegression(C=1e3).fit(X[tr], r[tr]); p[te] = lr.predict_proba(X[te])[:, 1]
        return p
    rng = np.random.default_rng(0); B_, L_ = a.boot, 4; draws = []
    for b in range(B_):
        seq = []
        while len(seq) < nq: st = int(rng.integers(0, nq)); seq.extend([(st + j) % nq for j in range(L_)])
        draws.append(np.bincount(np.array(seq[:nq]), minlength=nq).astype(float)[qpos])
    def rupture_incr(s_base, s_extra):
        p_b = loqo(lambda: s_base[:, None]); p_c = loqo(lambda: np.column_stack([s_base, s_extra]))
        dA = roc_auc_score(r, p_c) - roc_auc_score(r, p_b); dd = []
        for w in draws:
            if r[w > 0].sum() < 2 or r[w > 0].sum() == (w > 0).sum(): continue
            dd.append(roc_auc_score(r, p_c, sample_weight=w) - roc_auc_score(r, p_b, sample_weight=w))
        dd = np.array(dd); lo, hi = np.percentile(dd, [2.5, 97.5]); p = min(1.0, 2 * min((dd <= 0).mean(), (dd >= 0).mean()) + 1 / len(dd))
        return dict(AUC_base=roc_auc_score(r, p_b), AUC_base_plus_extra=roc_auc_score(r, p_c), dAUC=dA, IC_bas=lo, IC_haut=hi, p=p)
    rowsR = [dict(base=base, **rupture_incr(sc[base], sc["DAMP"])) for base in BASES]
    Rr = pd.DataFrame(rowsR); Rr["p_Holm"] = D.holm(Rr["p"].values)
    Rr["verdict"] = np.where((Rr["p_Holm"] < .05) & (Rr["dAUC"] > 0), "DAMP ajoute de l'information", "pas de preuve")
    print("\n=== Ruptures : AUC de la base seule vs base + score DAMP (leave-one-quarter-out ; blocs de trimestres) ===\n", Rr.to_string(index=False))
    Rr.to_csv(os.path.join(a.out, "complementarite_ruptures.csv"), index=False)
    # ---------------- 4) CONTRÔLE DE RÉTRÉCISSEMENT : DAMP est-il autre chose qu'un lissage ? ----------------
    crow = []; rrow = []
    for base in ["M2", "M3_GB"]:
        pc = dict(preds); pc["DAMP"] = 0.5 * (preds["M0"] + preds[base])            # prévision sans aucune information DAMP : simple lissage de la base vers M0
        for rn, (rm, mn) in make_regimes(base).items():
            res = encompass(E, y, pc, base, rm, mn)
            if res: crow.append(dict(base=base, regime=rn, **{k: res[k] for k in ("beta", "p", "gain_pct", "p_combo")}))
        sc_ctrl = -(np.nan_to_num(A["m"][E2]) + 0.5 * (preds["M0"][E2] + preds[base][E2]))
        rrow.append(dict(base=base, **rupture_incr(sc[base], sc_ctrl)))
    C = pd.DataFrame(crow); Cr = pd.DataFrame(rrow)
    print("\n=== CONTRÔLE : la même analyse avec un simple LISSAGE (moyenne de M0 et de la base) à la place de DAMP ===")
    print("Si le lissage 'ajoute' autant que DAMP, le résultat n'est pas de la complémentarité mais du rétrécissement.\n", C.to_string(index=False))
    print("\n--- Ruptures, contrôle de lissage ---\n", Cr.to_string(index=False))
    C.to_csv(os.path.join(a.out, "controle_lissage_marge.csv"), index=False); Cr.to_csv(os.path.join(a.out, "controle_lissage_ruptures.csv"), index=False)
    print("\n=== LECTURE ===")
    ok = M[M["verdict"] == "DAMP ajoute de l'information"]; okr = Rr[Rr["verdict"] == "DAMP ajoute de l'information"]
    print(f"Marge : {len(ok)} test(s) sur {len(M)} avec ajout d'information significatif après Holm." + (" Cas : " + "; ".join(f"{b} / {g}" for b, g in zip(ok.base, ok.regime)) if len(ok) else ""))
    print(f"Ruptures : {len(okr)} test(s) sur {len(Rr)}." + (" Bases : " + ", ".join(okr.base) if len(okr) else ""))
    print("Pour chaque résultat positif ci-dessus, compare le gain de DAMP à celui du lissage : DAMP n'est complémentaire que s'il fait nettement mieux que le lissage.")
    print("Rappel : analyse post hoc sur les données déjà utilisées ; un résultat positif serait une hypothèse à confirmer sur données indépendantes, un résultat nul est cohérent avec les tests précédents.")
    with open(os.path.join(a.out, "journal.txt"), "w", encoding="utf-8") as f: f.write(f"POST HOC, non préenregistré. {datetime.datetime.utcnow().isoformat()}Z\n")

if __name__ == "__main__":
    main()
