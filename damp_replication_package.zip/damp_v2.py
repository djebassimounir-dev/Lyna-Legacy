#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DAMP v2 : PROTOCOLE TRANSVERSAL sur le commerce de gros et de détail (SEC EDGAR)          version 2.1

Question : parmi les entreprises d'un MÊME trimestre, les variables opérationnelles (jours de stock, délai de règlement, rigidité,
répercussion) et la structure DAMP prédisent-elles QUELLES entreprises voient leur marge se dégrader le plus après un choc énergétique ?
(La moyenne de chaque trimestre est retirée : seule la comparaison entre entreprises compte. Les chocs communs disparaissent.)

Cible : variation de marge à 4 trimestres, moins la moyenne du trimestre d'origine.
Mesure principale : erreur quadratique moyenne PAR TRIMESTRE (cible et prévisions sans la moyenne du trimestre), comparée entre modèles par un test de
Diebold-Mariano HAC sur la série trimestrielle des différences (les cibles recouvrent 4 trimestres). Elle pèse naturellement plus les trimestres de choc.
Mesure complémentaire (descriptive) : IC = corrélation de rang (Spearman) trimestre par trimestre ; elle donne le même poids à tous les trimestres, y compris les calmes.
Tous les modèles incluent la marge courante (retour à la moyenne, déterminant n°1 de la variation de marge) ; la question est ce que le choc et DAMP ajoutent.
Hypothèses (2 confirmatoires, correction de Holm) :
   H1 : l'erreur de DAMP est inférieure à celle de XS2   (DAMP bat la régression avec effets principaux et interactions)
   H2 : l'erreur de DAMP est inférieure à celle de XS0   (DAMP ajoute de l'information au simple retour à la moyenne ; XS0 = marge courante seule)
Secondaires (autre famille de Holm) : DAMP vs XS1, XS3_GB, DAMP sans lambda.
DAMP v2 utilise l'estimateur BORNÉ (variables standardisées à +-3, exposant de lambda à +-2) : choix de conception issu de l'étude v1.

Étapes (dans l'ordre) :
  python damp_v2.py data                 télécharge EDGAR/FRED (SIC 5000-5999) et construit le panel
  python damp_v2.py check                contrôles SANS aucune performance de modèle
  python damp_v2.py certificat [--quick] puissance du protocole (obligatoire avant le gel ; reprenable)
  python damp_v2.py freeze               gèle script + panel + configuration + certificat (empreintes SHA-256)
  python damp_v2.py test [--force]       UN SEUL passage ; refuse si quelque chose a changé depuis le gel
Option de validation : --synthetic [--world damp|noise] sur n'importe quelle étape (aucun réseau).
Identifiant SEC : fichier sec_user_agent.txt (comme pour damp_edgar.py). Ce script doit être dans le dossier de damp_edgar.py et detectability.py.
"""
import os, sys, json, time, hashlib, argparse, datetime, warnings
import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import minimize
from scipy.signal import lfilter
from sklearn.ensemble import HistGradientBoostingRegressor
import damp_edgar as D
import detectability as DET
warnings.filterwarnings("ignore")

CFG2 = dict(MIN_FIRMS_Q=30, SIC_RANGE=(5000, 5999), SIC_EXCLUDE=[], MIN_QUARTERS=8, KAPPAS="0,0.5,1,1.5,2,3", REPS=10)
H, NL = D.CFG["H"], D.CFG["NL"]
THETA0 = [[0.5, 0.3, 0, 0, 0, 0, 0], [0.3, 0.8, 0.1, -.3, .3, .3, -.3]]
DAMP_FLAGS = {"DAMP": dict(lam=True, mem=True, absorb=True, a=D.CFG["A_TORSION"]),
              "DAMP_sans_lambda": dict(lam=False, mem=True, absorb=True, a=D.CFG["A_TORSION"])}
MODELS = ["XS0", "XS1", "XS2", "XS3_GB", "DAMP", "DAMP_sans_lambda"]
CERT_TAG = "v21"

# ------------------------------------------------------------------ utilitaires
def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""): h.update(c)
    return h.hexdigest()

def mode_name(a): return "synthetic_" + a.world if a.synthetic else "retail"

def apply_mode(a):
    if a.synthetic: D.CFG.update(INIT=40, BURN=8, START_YEAR=2005)
    else:
        D.CFG.update(SIC_RANGE=CFG2["SIC_RANGE"], SIC_EXCLUDE=CFG2["SIC_EXCLUDE"], MIN_QUARTERS=CFG2["MIN_QUARTERS"])
        for k, extra in {"receivables": ["ReceivablesNetCurrent", "AccountsAndOtherReceivablesNetCurrent"],
                         "revenue": ["SalesRevenueGoodsNet"]}.items():
            D.TAGS[k] = D.TAGS[k] + [t for t in extra if t not in D.TAGS[k]]

def panel_path(a):
    f = f"panel_{mode_name(a)}.csv.gz"
    if not os.path.exists(f): sys.exit(f"{f} introuvable : lance d'abord l'étape 'data'.")
    return f

def xs_demean(X, mask):
    """Retire, trimestre par trimestre, la moyenne des entreprises du masque. Hors masque -> 0."""
    Xm = np.where(mask, X, np.nan); mu = np.nanmean(Xm, axis=0, keepdims=True)
    return np.where(mask, X - np.nan_to_num(mu), 0.0)

def targets_xs(A):
    y, R = D.make_targets(A); ok = A["obs"] & ~np.isnan(y)
    yd = np.where(ok, xs_demean(np.nan_to_num(y), ok), np.nan)
    return y, yd, ok

# ------------------------------------------------------------------ variables et modèles
def features_xs(A, model, theta=None, scale=1.0):
    obs = A["obs"]; S = D.lag_stack(A["s0"], NL); Zs = [np.nan_to_num(A["z_" + k]) for k in D.XN]
    M = np.nan_to_num(A["m"])[:, :, None]                                    # marge courante : retour à la moyenne
    if model == "XS0": X = M
    elif model == "XS1": X = np.concatenate([M, S], axis=2)
    elif model == "XS2":
        main = [z[:, :, None] for z in Zs]; inter = [S[:, :, j:j+1] * z[:, :, None] for z in Zs for j in range(NL)]
        X = np.concatenate([M, S] + main + inter, axis=2)
    elif model == "XS3_GB": X = np.concatenate([M, S] + [z[:, :, None] for z in Zs], axis=2)
    else: X = np.concatenate([M, DET.damp_F_bounded(A, theta, DAMP_FLAGS[model], scale)[:, :, None]], axis=2)
    out = np.empty_like(X, dtype=float)
    for j in range(X.shape[2]): out[:, :, j] = xs_demean(X[:, :, j], obs)
    return out

def fit_damp_xs(A, yd, rows, model, scale):
    fl = DAMP_FLAGS[model]; bnds = [(0, .95), (0, 2), (-1, 1)] + [(-2, 2)] * 4
    if not fl["lam"]: bnds[3:] = [(0, 0)] * 4
    yy = yd[rows]; den = np.mean(yy ** 2)
    def loss(th):
        X = features_xs(A, model, th, scale)[rows]                           # (n, 2) : [marge courante, pression F]
        c, *_ = np.linalg.lstsq(X, yy, rcond=None)
        return np.mean((yy - X @ c) ** 2) / den
    best = None
    for st in THETA0:
        st = [min(max(v, lo), hi) for v, (lo, hi) in zip(st, bnds)]
        r = minimize(loss, st, method="L-BFGS-B", bounds=bnds, options=dict(maxiter=60, ftol=1e-10, eps=1e-4))
        if best is None or r.fun < best.fun: best = r
    return best.x

def features_xs_cached(A, model, th, scale): return features_xs(A, model, th, scale)

def fit_predict_xs(model, A, yd, rows, scale):
    N, T = A["N"], A["T"]
    if model.startswith("DAMP"):
        th = fit_damp_xs(A, yd, rows, model, scale); X = features_xs(A, model, th, scale)
        c, *_ = np.linalg.lstsq(X[rows], yd[rows], rcond=None)
        return X @ c, th
    X = features_xs(A, model); Xf = X.reshape(N * T, -1); r = rows.reshape(-1); yv = np.nan_to_num(yd).reshape(-1)
    if model == "XS3_GB":
        gb = HistGradientBoostingRegressor(max_iter=150, learning_rate=0.05, max_depth=4, random_state=D.CFG["SEED"]).fit(Xf[r], yv[r]); p = gb.predict(Xf)
    else:
        c = D.ridge_fit(Xf[r], yv[r]); p = D.ridge_predict(c, Xf)
    return p.reshape(N, T), None

def walk_forward_xs(A, models, verbose=True, max_refits=None):
    y, yd, ok = targets_xs(A); N, T = A["N"], A["T"]
    preds = {m: np.full((N, T), np.nan) for m in models}; plog = []
    for k, t_r in enumerate(range(D.CFG["INIT"], T - H - 1, D.CFG["REFIT"])):
        if max_refits and k >= max_refits: break
        tr_last = t_r - H - D.CFG["PUB_LAG"]; cols = np.arange(t_r + 1, min(t_r + D.CFG["REFIT"], T - H - 1) + 1)
        rows = ok.copy(); rows[:, :D.CFG["BURN"]] = False; rows[:, tr_last + 1:] = False
        pos = A["s0"][:, :tr_last + 1]; pos = pos[pos > 0]; scale = pos.std() if len(pos) > 5 else 1.0
        for m in models:
            p, th = fit_predict_xs(m, A, yd, rows, scale); preds[m][:, cols] = p[:, cols]
            if th is not None: plog.append(dict(t=t_r, modèle=m, **dict(zip(["rho", "a0", "a1", "b_stock", "b_delay", "b_rig", "b_pass"], th))))
        if verbose: print(f"origine {t_r} ok", end="; ", flush=True)
    return preds, pd.DataFrame(plog), y, ok

# ------------------------------------------------------------------ évaluation
STATS = ["mse", "trunc", "mae", "ic"]
STAT_LABEL = {"mse": "erreur quadratique", "trunc": "erreur quadratique tronquée (robuste)", "mae": "erreur absolue", "ic": "corrélation de rang (IC)"}

def ic_series(A, preds, y, ok, models, drop_cols=None):
    """Retourne cols, IC par trimestre, R2 transversal, et S[stat][modèle] = série trimestrielle de PERTE (plus petit = meilleur) pour 4 statistiques."""
    E = ok.copy()
    for m in models: E &= ~np.isnan(preds[m])
    if drop_cols is not None and len(drop_cols): E[:, drop_cols] = False
    cols = [t for t in range(A["T"]) if E[:, t].sum() >= CFG2["MIN_FIRMS_Q"]]
    IC = {m: np.array([stats.spearmanr(preds[m][E[:, t], t], y[E[:, t], t]).correlation for t in cols]) for m in models}
    S = {k: {m: np.empty(len(cols)) for m in models} for k in ("mse", "trunc", "mae")}; num = {m: 0.0 for m in models}; den = 0.0
    for i, t in enumerate(cols):
        yy = y[E[:, t], t]; yy = yy - yy.mean(); den += np.sum(yy ** 2)
        c = max(3 * 1.4826 * np.median(np.abs(yy - np.median(yy))), 1e-9)          # échelle robuste du trimestre
        for m in models:
            pp = preds[m][E[:, t], t]; e = yy - (pp - pp.mean())
            S["mse"][m][i] = np.mean(e ** 2); S["trunc"][m][i] = np.mean(np.minimum(e ** 2, c ** 2)); S["mae"][m][i] = np.mean(np.abs(e)); num[m] += np.sum(e ** 2)
    S["ic"] = {m: -IC[m] for m in models}
    R2 = {m: 1 - num[m] / den for m in models}
    return cols, IC, R2, S

def tests_xs(L, models):
    """Tests confirmatoires : DAMP a-t-il une erreur quadratique transversale plus faible ? (DM-HAC-HLN sur la série trimestrielle ; d < 0 = DAMP meilleur)."""
    rows = []
    for b_ in [x for x in models if x != "DAMP"]:
        d = L["DAMP"] - L[b_]; s_, p_ = D.dm_test(d, H)
        rows.append(dict(famille="P" if b_ in ("XS0", "XS2") else "S", test=f"perte(DAMP) < perte({b_})", diff_perte_e4=1e4 * float(d.mean()), stat=float(s_), p=float(p_), signe_ok=bool(d.mean() < 0)))
    T = pd.DataFrame(rows); T["p_Holm"] = np.nan
    for fam in ("P", "S"):
        idx = T.index[T["famille"] == fam]; T.loc[idx, "p_Holm"] = D.holm(T.loc[idx, "p"].values)
    T["verdict"] = np.where((T["p_Holm"] < .05) & T["signe_ok"], "confirmé", np.where(T["p_Holm"] < .05, "significatif en sens inverse", "non confirmé"))
    return T

def tests_ic(IC, models):
    """Complément descriptif (non confirmatoire) : IC moyen de DAMP face aux autres, même poids pour tous les trimestres."""
    rows = []
    for b_ in [x for x in models if x != "DAMP"]:
        d = IC["DAMP"] - IC[b_]; s_, p_ = D.dm_test(-d, H); rows.append(dict(comparaison=f"IC(DAMP) - IC({b_})", delta_IC=float(d.mean()), stat=float(s_), p=float(p_)))
    return pd.DataFrame(rows)

# ------------------------------------------------------------------ étape data / check
def stage_data(a):
    f = f"panel_{mode_name(a)}.csv.gz"
    if a.synthetic:
        panel = D.simulate_panel(400, 88, "damp", 42) if a.world == "damp" else DET.simulate_noise_panel(400, 88, 42)
    else:
        D.CFG["UA"] = D.get_ua(); D.CFG["DRY_TARGET"] = None; panel = D.build_real_panel(D.CFG)
    panel.to_csv(f, index=False, compression="gzip")
    print(f"\nPanel enregistré : {f} | lignes : {len(panel)} | entreprises : {panel['firm'].nunique()} | trimestres : {panel['q'].nunique()}")
    print(panel.groupby(panel["q"] // 4 + D.CFG["START_YEAR"])["firm"].nunique().to_string())

def stage_check(a):
    panel = pd.read_csv(panel_path(a)); A = D.to_arrays(panel); y, yd, ok = targets_xs(A)
    nq = ok.sum(axis=0); good = int(np.sum(nq >= CFG2["MIN_FIRMS_Q"]))
    print(f"Panel : {A['N']} entreprises x {A['T']} trimestres | lignes exploitables : {int(A['obs'].sum())}")
    print(f"Entreprises avec cible observée par trimestre : médiane {int(np.median(nq[nq > 0]))} | min {int(nq[nq > 0].min())} | max {int(nq.max())}")
    print(f"Trimestres avec au moins {CFG2['MIN_FIRMS_Q']} entreprises : {good}")
    if good < 20: print("ATTENTION : moins de 20 trimestres exploitables : pouvoir très limité.")
    if "expo_info" in panel: print(f"Exposition estimée en propre : {panel.groupby('firm')['expo_info'].first().mean():.0%} des entreprises")
    cz = D.causality_test(A, t0=min(D.CFG["INIT"] + 3, A["T"] - 2)); print("Test de causalité :", cz)
    if not all(cz.values()): sys.exit("FUITE DÉTECTÉE.")
    print("Contrôles terminés (aucune performance de modèle n'a été calculée).")

# ------------------------------------------------------------------ certificat de détectabilité (transversal)
def make_delta(A):
    Pi = DET.injected_pressure(A); pp = Pi[Pi > 0]; Pn = Pi / (pp.std() if len(pp) > 5 else 1.0)
    Pl = np.zeros_like(Pn); Pl[:, 1:] = Pn[:, :-1]
    return lfilter([1.0], [1.0, -DET.PHI], -Pl, axis=1)

def xs_scale(A, delta):
    y, _ = D.make_targets(A); ok = A["obs"] & ~np.isnan(y)
    d4 = np.full_like(delta, np.nan); d4[:, :-H] = delta[:, H:] - delta[:, :-H]; ok2 = ok & ~np.isnan(d4)
    yd = xs_demean(np.nan_to_num(y), ok2); dd = xs_demean(np.nan_to_num(d4), ok2)
    return float(np.std(yd[ok2])), float(np.std(dd[ok2]))

def stage_certificat(a):
    panel = pd.read_csv(panel_path(a)); out = "certificat_v2"; os.makedirs(out, exist_ok=True); runs_f = os.path.join(out, f"runs_{mode_name(a)}_{CERT_TAG}.csv")
    kappas = [float(x) for x in ("0,1,2" if a.quick else CFG2["KAPPAS"]).split(",")]; reps = 3 if a.quick else CFG2["REPS"]
    runs = pd.read_csv(runs_f) if os.path.exists(runs_f) else pd.DataFrame()
    done = set((round(float(r.kappa), 4), int(r.rep)) for r in runs.itertuples()) if not runs.empty else set()
    groups = {f: g for f, g in panel.groupby("firm")}; ids = np.array(list(groups)); t_start = time.time()
    print(f"Certificat v2 : {len(ids)} entreprises | intensités {kappas} x {reps} réplications (reprenable)")
    for rep in range(reps):
        todo = [k for k in kappas if (round(k, 4), rep) not in done]
        if not todo: continue
        rng = np.random.default_rng(2000 + rep); draw = rng.choice(ids, size=len(ids), replace=True)
        panel_r = pd.concat([groups[f].assign(firm=i) for i, f in enumerate(draw)], ignore_index=True); A = D.to_arrays(panel_r)
        delta = make_delta(A); sd_y, sd_d = xs_scale(A, delta)
        Pi_true = DET.damp_F_bounded(A, DET.THETA_STAR, DAMP_FLAGS["DAMP"], (A["s0"][A["s0"] > 0].std() if (A["s0"] > 0).sum() > 5 else 1.0))
        for kappa in todo:
            t0 = time.time(); B = DET.inject(A, delta, kappa * sd_y / max(sd_d, 1e-12))
            preds, _, y, ok = walk_forward_xs(B, ["XS0", "XS2", "DAMP"], verbose=False)
            cols, IC, R2, SS = ic_series(B, preds, y, ok, ["XS0", "XS2", "DAMP"])
            det = {}
            for k in STATS:
                for ref in ("XS0", "XS2"):
                    d = SS[k][ref] - SS[k]["DAMP"]; _, p_ = D.dm_test(-d, H)               # d > 0 : DAMP meilleur
                    det[f"p_{k}_vs_{ref}"] = float(p_); det[f"detect_{k}_vs_{ref}"] = int(d.mean() > 0 and p_ < .05)
            Md = xs_demean(np.nan_to_num(B["m"]), B["obs"]); Fo = xs_demean(Pi_true, B["obs"]); yd_ = np.where(ok, xs_demean(np.nan_to_num(y), ok), 0.0)
            def fitted_ic(X):
                c, *_ = np.linalg.lstsq(X[ok], yd_[ok], rcond=None); P = X @ c
                return np.mean([stats.spearmanr(P[ok[:, t], t], y[ok[:, t], t]).correlation for t in cols])
            ic_or = fitted_ic(np.stack([Md, Fo], axis=2)); ic_m = fitted_ic(Md[:, :, None])
            row = dict(kappa=kappa, rep=rep, IC_DAMP=float(IC["DAMP"].mean()), IC_XS0=float(IC["XS0"].mean()), IC_XS2=float(IC["XS2"].mean()), **det,
                       IC_oracle=float(ic_or), IC_retour_moyenne=float(ic_m))
            runs = pd.concat([runs, pd.DataFrame([row])], ignore_index=True); runs.to_csv(runs_f, index=False)
            print(f"  rep {rep+1}/{reps} kappa={kappa:<4} IC DAMP={row['IC_DAMP']:+.3f} XS0={row['IC_XS0']:+.3f} | détecte vs XS0 (mse/trunc/mae/ic) = {row['detect_mse_vs_XS0']}/{row['detect_trunc_vs_XS0']}/{row['detect_mae_vs_XS0']}/{row['detect_ic_vs_XS0']} ({time.time()-t0:.0f}s ; total {(time.time()-t_start)/60:.0f} min)", flush=True)
    summarize_cert(runs, out, a)

def summarize_cert(runs, out, a):
    rows = []
    for k, d in runs.groupby("kappa"):
        n = len(d); r = dict(kappa=k, reps=n)
        for st in STATS:
            for ref in ("XS0", "XS2"): r[f"{st}_vs_{ref}"] = d[f"detect_{st}_vs_{ref}"].sum() / n
        r["IC_DAMP"] = d["IC_DAMP"].mean(); r["IC_XS0"] = d["IC_XS0"].mean(); rows.append(r)
    T = pd.DataFrame(rows).sort_values("kappa").reset_index(drop=True); ks = T["kappa"].values
    T.to_csv(os.path.join(out, f"certificat_{mode_name(a)}_{CERT_TAG}.csv"), index=False)
    pd.set_option("display.width", 230, "display.float_format", lambda x: f"{x:.2f}")
    print("\n" + "=" * 118 + "\nCERTIFICAT DE DÉTECTABILITÉ v2.1 (transversal) : puissance par statistique (part des réplications où DAMP est significativement meilleur)\n" + "=" * 118)
    print("--- H2 : DAMP vs retour à la moyenne seul (XS0) ---"); print(T[["kappa", "reps"] + [f"{s_}_vs_XS0" for s_ in STATS] + ["IC_DAMP", "IC_XS0"]].to_string(index=False))
    print("--- H1 : DAMP vs régression à interactions (XS2) ---"); print(T[["kappa", "reps"] + [f"{s_}_vs_XS2" for s_ in STATS]].to_string(index=False))
    fa = T.loc[T["kappa"] == 0]; summ = {}
    for st in STATS:
        k0 = DET.kmin(ks, T[f"{st}_vs_XS0"].values); k2 = DET.kmin(ks, T[f"{st}_vs_XS2"].values); summ[st] = (k0, k2)
        fp = f"{float(fa[f'{st}_vs_XS0'].iloc[0]):.2f}/{float(fa[f'{st}_vs_XS2'].iloc[0]):.2f}" if len(fa) else "n/a"
        print(f"  {st:6s} ({STAT_LABEL[st]}) : kappa minimal détectable à 80 % : H2 {k0:.2f} | H1 {k2:.2f} | faux positifs à kappa=0 (XS0/XS2) : {fp}")
    print("\nRègle de choix (à appliquer AVANT le gel) : retenir la statistique dont le kappa minimal H2 est le plus bas, avec faux positifs à kappa=0 <= 0.10. Si aucune ne détecte à kappa <= 1.5, le test n'est pas concluant sur ce panel : on ne le lance pas.")
    txt = (f"DETECTABILITY CERTIFICATE v2.1 (cross-sectional protocol)\nGenerated {datetime.datetime.utcnow().isoformat()}Z\n" +
           "".join(f"Statistic {st} ({STAT_LABEL[st]}): minimum detectable kappa at 80% power: H2 (vs mean-reversion only) {summ[st][0]:.2f}; H1 (vs interaction regression) {summ[st][1]:.2f}.\n" for st in STATS) +
           "kappa = SD of the injected DAMP margin change / SD of the cross-sectional target. Real panel structure and noise are kept; firms are resampled; the injected model is correctly specified, so these are upper bounds. p-values are not Holm-adjusted.\n")
    open(os.path.join(out, f"certificate_{mode_name(a)}_{CERT_TAG}_EN.txt"), "w", encoding="utf-8").write(txt)
    print(f"\nFichiers : {out}/certificat_{mode_name(a)}_{CERT_TAG}.csv et certificate_{mode_name(a)}_{CERT_TAG}_EN.txt")

# ------------------------------------------------------------------ freeze / test
def stage_freeze(a):
    f = panel_path(a); cert = os.path.join("certificat_v2", f"certificat_{mode_name(a)}_{CERT_TAG}.csv")
    if not os.path.exists(cert): sys.exit("Certificat de détectabilité absent : lance d'abord 'python damp_v2.py certificat' (obligatoire avant le gel).")
    if a.stat not in STATS: sys.exit(f"Choisis la statistique primaire : python damp_v2.py freeze --stat {{{'|'.join(STATS)}}}  (d'après le certificat)")
    me = os.path.abspath(__file__); panel = pd.read_csv(f)
    rec = dict(mode=mode_name(a), stat_primaire=a.stat, horodatage_utc=datetime.datetime.utcnow().isoformat() + "Z", script=os.path.basename(me), script_sha256=sha256_file(me),
               panel_sha256=sha256_file(f), certificat_sha256=sha256_file(cert), damp_edgar_sha256=sha256_file(os.path.abspath(D.__file__)),
               detectability_sha256=sha256_file(os.path.abspath(DET.__file__)), lignes=int(len(panel)), entreprises=int(panel["firm"].nunique()),
               config={k: v for k, v in D.CFG.items() if k != "UA"}, config_v2=CFG2)
    out = f"protocole_fige_v2_{mode_name(a)}.json"; json.dump(rec, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=2, default=str)
    print(json.dumps({k: rec[k] for k in ("mode", "horodatage_utc", "script_sha256", "panel_sha256", "certificat_sha256", "damp_edgar_sha256", "detectability_sha256")}, indent=2))
    print(f"\nFichier écrit : {out}\nÀ FAIRE MAINTENANT : dépose sur Zenodo (en anglais) : ce JSON, damp_v2.py, damp_edgar.py, detectability.py, le certificat, le panel et le protocole.")
    print("Ne modifie plus AUCUN de ces fichiers, puis seulement ensuite lance 'test'.")

def stage_test(a):
    mode = mode_name(a); f = panel_path(a); outdir = f"resultats_v2_{mode}"
    if a.synthetic: print("*" * 90 + "\n  MODE SIMULÉ : RÉSULTATS EXPLORATOIRES, NE PAS PUBLIER\n" + "*" * 90)
    else:
        fz = f"protocole_fige_v2_{mode}.json"
        if not os.path.exists(fz): sys.exit("Protocole non gelé : lance 'freeze' puis dépose les fichiers sur Zenodo.")
        rec = json.load(open(fz, encoding="utf-8"))
        for key, path in [("script_sha256", os.path.abspath(__file__)), ("panel_sha256", f), ("damp_edgar_sha256", os.path.abspath(D.__file__)),
                          ("detectability_sha256", os.path.abspath(DET.__file__))]:
            if rec[key] != sha256_file(path): sys.exit(f"{os.path.basename(path)} a changé depuis le gel : test refusé.")
        print(f"Protocole gelé le {rec['horodatage_utc']} : empreintes vérifiées. Statistique primaire : {rec['stat_primaire']}")
        a.stat = rec["stat_primaire"]
    if os.path.exists(os.path.join(outdir, "tests.csv")) and not a.force: sys.exit(f"Des résultats existent déjà dans {outdir}/ : second passage refusé (--force sera journalisé).")
    stat = a.stat if a.stat in STATS else "mse"; os.makedirs(outdir, exist_ok=True); A = D.to_arrays(pd.read_csv(f)); t0 = time.time()
    cz = D.causality_test(A, t0=min(D.CFG["INIT"] + 3, A["T"] - 2)); assert all(cz.values()), "FUITE DÉTECTÉE"
    preds, plog, y, ok = walk_forward_xs(A, MODELS); print(f"\nWalk-forward terminé en {time.time()-t0:.0f}s")
    pd.set_option("display.width", 200, "display.float_format", lambda x: f"{x:.4f}")
    for label, tag, dc in [("PRINCIPAL", "principal", None), ("ROBUSTESSE : origines Covid 2019T1-2020T4 exclues", "robustesse_covid", D_covid(A["T"]))]:
        cols, IC, R2, SS = ic_series(A, preds, y, ok, MODELS, dc)
        S = pd.DataFrame([dict(modèle=m, trimestres=len(cols), MSE_trim_e4=1e4 * SS["mse"][m].mean(), R2_transversal=R2[m], IC_moyen=IC[m].mean()) for m in MODELS])
        T = tests_xs(SS[stat], MODELS); Ti = tests_ic(IC, MODELS); print("\n" + "=" * 100 + f"\n{label}\n" + "=" * 100)
        print("\n--- Prédictibilité transversale ---\n", S.to_string(index=False)); print("\n--- Tests confirmatoires (famille P) et secondaires (S) : Holm par famille ; diff_perte_e4 < 0 = DAMP meilleur ; statistique primaire = " + stat + " ---\n", T.to_string(index=False))
        print("\n--- Complément descriptif : IC ---\n", Ti.to_string(index=False)); Ti.to_csv(f"{outdir}/{tag}_ic_tests.csv", index=False)
        S.to_csv(f"{outdir}/{tag}_ic.csv", index=False); T.to_csv(f"{outdir}/{tag}_tests.csv", index=False)
        if tag == "principal": T.to_csv(f"{outdir}/tests.csv", index=False)
    rows = []
    for label, AA in [("réel", A), ("x permutés", D.permute_x_within_quarter(A)), ("chocs décalés", D.shift_shocks(A))]:
        if label == "réel": pr, yy, okk = preds, y, ok
        else: pr, _, yy, okk = walk_forward_xs(AA, ["XS0", "XS2", "DAMP"], verbose=False)
        c, IC, R2f, _ = ic_series(AA, pr, yy, okk, ["XS0", "XS2", "DAMP"]); rows.append(dict(scénario=label, R2_XS0=R2f["XS0"], R2_XS2=R2f["XS2"], R2_DAMP=R2f["DAMP"], gain_R2_DAMP_vs_XS0=R2f["DAMP"] - R2f["XS0"]))
    FAL = pd.DataFrame(rows); print("\n=== Falsification : IC moyen ; la colonne gain_R2_DAMP_vs_XS0 doit s'effondrer vers 0 quand les variables ou les chocs sont brouillés ===\n", FAL.to_string(index=False))
    FAL.to_csv(f"{outdir}/falsification.csv", index=False); plog.to_csv(f"{outdir}/parametres.csv", index=False)
    with open(f"{outdir}/journal.jsonl", "a", encoding="utf-8") as fj: fj.write(json.dumps(dict(horodatage_utc=datetime.datetime.utcnow().isoformat() + "Z", mode=mode, force=bool(a.force), duree_s=round(time.time() - t0))) + "\n")
    print(f"\nRésultats enregistrés dans {outdir}/")

def D_covid(T):
    base = (2020 - D.CFG["START_YEAR"]) * 4
    return np.array([c for c in range(max(base - H, 0), min(base + 3, T - 1) + 1)])

def main():
    ap = argparse.ArgumentParser(description="DAMP v2 transversal")
    ap.add_argument("stage", choices=["data", "check", "certificat", "freeze", "test"])
    ap.add_argument("--synthetic", action="store_true"); ap.add_argument("--world", default="damp", choices=["damp", "noise"])
    ap.add_argument("--quick", action="store_true"); ap.add_argument("--force", action="store_true"); ap.add_argument("--stat", default=None)
    a = ap.parse_args(); apply_mode(a)
    {"data": stage_data, "check": stage_check, "certificat": stage_certificat, "freeze": stage_freeze, "test": stage_test}[a.stage](a)

if __name__ == "__main__":
    main()
