#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DAMP — protocole sur données d'entreprises (EDGAR + FRED)           version 1.3

Étapes (à lancer dans cet ordre) :
  python damp_edgar.py data   [--dry]     télécharge EDGAR/FRED, construit le panel, affiche des diagnostics
                                          (--dry = échantillon de 600 entreprises, essai technique)
  python damp_edgar.py check              contrôles SANS aucune performance de modèle (causalité, événements, couverture)
  python damp_edgar.py freeze             gèle le protocole : empreintes SHA-256 du script, du panel et de la configuration
  python damp_edgar.py test   [--dry] [--force] [--smoke]
                                          exécute les modèles UNE SEULE FOIS (refuse si le script/panel ont changé depuis le gel,
                                          ou si des résultats existent déjà, sauf --force qui est journalisé)
Option de validation : ajouter --synthetic à n'importe quelle étape (panel simulé, aucune connexion réseau).

Identifiant SEC : crée un fichier  sec_user_agent.txt  contenant  « Prénom Nom ton.email@exemple.com »
(ou définis la variable d'environnement SEC_UA). Il n'est PAS écrit dans ce script, afin que son empreinte reste stable.
"""
import os, re, sys, io, json, time, hashlib, argparse, warnings, datetime
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.signal import lfilter
from scipy import stats
warnings.filterwarnings("ignore")

CFG = dict(
    H=4, NL=4, REFIT=4,
    INIT=28,             # 1re origine de test : 2016T1 (START_YEAR=2009)
    BURN=4, PUB_LAG=1,
    L=8, TAU=4.0, A_TORSION=-0.5,
    START_YEAR=2009, END_YEAR=2024,       # l'XBRL n'existe pas avant 2009-2011
    PRE_END_Q=23,        # exposition & répercussion estimées avec t <= 2014T4 uniquement
    MIN_REV=1e7, MIN_QUARTERS=8,
    SIC_RANGE=(2000, 3999), SIC_EXCLUDE=[(2833, 2836)],
    ENERGY_SERIES="PPIENG",
    DRY_FIRMS=600,
    SIM_WORLD="damp", N_SIM=300, T_SIM=88,
    SEED=42, B_BOOT=300, CACHE="edgar_cache", UA="",
)

# =====================================================================================
#  DONNÉES (EDGAR / FRED / simulateur)
# =====================================================================================
def torsional_kernel(L, a, tau):
    ell = np.arange(L + 1, dtype=float)
    raw = (ell + 1.0) ** a * np.exp(-ell / tau)
    return raw / raw.sum()

# ------------------------------------------------------------------ simulateur
def simulate_panel(N=300, T=88, world="damp", seed=42):
    """Deux mondes. 'damp' : la marge suit la dynamique DAMP (absorption, mémoire, lambda).
    'null' : effet instantané, identique pour tous, sans variables opérationnelles."""
    rng = np.random.default_rng(seed)
    g = np.zeros(T)
    for t in range(1, T):
        g[t] = 0.8 * g[t-1] + rng.normal(0, 0.04)
    for t0, amp in [(30, .25), (52, .25), (66, .30), (78, .25)]:
        g[t0] += amp
    e = rng.lognormal(-0.3, 0.5, N)
    s = e[:, None] * np.maximum(g, 0)[None, :]                      # choc défavorable exposé
    Z = {k: np.zeros((N, T)) for k in ["stock", "delay", "rig", "pass"]}
    for k in Z:
        Z[k][:, 0] = rng.standard_normal(N)
        for t in range(1, T):
            Z[k][:, t] = 0.9 * Z[k][:, t-1] + np.sqrt(1 - 0.81) * rng.standard_normal(N)
    mu = rng.normal(0.06, 0.04, N)
    m = np.zeros((N, T)); m[:, 0] = mu + rng.normal(0, 0.02, N)
    sscale = s[s > 0].std()
    K = torsional_kernel(8, -0.5, 4.0); rho = 0.5
    M = np.zeros(N); dhist = np.zeros((N, 9)); qh = np.zeros((N, 9))
    for t in range(T - 1):
        if world == "damp":
            absorb = np.maximum(0, 0.3 + 0.2 * Z["stock"][:, t]) * sscale
            q = np.maximum(0, s[:, t] - absorb)
            qh = np.roll(qh, 1, axis=1); qh[:, 0] = q
            M = rho * M + (1 - rho) * (qh @ K)
            lam = np.exp(-0.3*Z["stock"][:, t] + 0.5*Z["delay"][:, t] + 0.4*Z["rig"][:, t] - 0.4*Z["pass"][:, t])
            pi = 0.5 * lam * M
        else:
            pi = 0.05 * s[:, t]
        m[:, t+1] = m[:, t] + 0.25 * (mu - m[:, t]) - pi + rng.normal(0, 0.012, N)
    rows = []
    for t in range(T):
        rows.append(pd.DataFrame(dict(firm=np.arange(N), q=t, m=m[:, t], s=s[:, t],
            stock=40 + 15*Z["stock"][:, t], delay=45 + 15*Z["delay"][:, t],
            rig=0.25 + 0.08*Z["rig"][:, t], **{"pass": 0.6 + 0.2*Z["pass"][:, t]})))
    return pd.concat(rows, ignore_index=True)

# ------------------------------------------------------------------ réseau (robuste, avec reprises et cache)
import requests, io
from requests.exceptions import RequestException, InvalidHeader, InvalidURL, MissingSchema
_SESSION = requests.Session()
_NREQ = [0]
def _tick():
    _NREQ[0] += 1
    if _NREQ[0] % 25 == 0: print('.', end='', flush=True)   # un point = 25 vraies requetes reseau

def _get(url, headers=None, tries=6):
    """GET robuste : réessaie avec attente croissante sur timeouts, 429 et erreurs 5xx.
    N'avale JAMAIS une erreur réseau (sinon un échec serait pris pour une donnée absente)."""
    last = None
    for k in range(tries):
        try:
            r = _SESSION.get(url, headers=headers, timeout=(20, 60))
            if r.status_code in (429, 500, 502, 503, 504):
                last = f"HTTP {r.status_code}"
            else:
                return r
        except (InvalidHeader, InvalidURL, MissingSchema) as e:
            raise RuntimeError(f"Requête invalide ({type(e).__name__}) : {e}\n"
                               "-> problème d'en-tête : vérifie sec_user_agent.txt (UNE seule ligne : Prenom Nom email).")
        except RequestException as e:
            last = type(e).__name__
        if k == tries - 1: break
        wait = min(60, 2 ** (k + 1))
        print(f"  [réseau] {last} -- nouvel essai {k+1}/{tries-1} dans {wait}s")
        time.sleep(wait)
    raise RuntimeError(f"Échec réseau après {tries} essais ({last}) : {url}\n"
                       "Relance simplement la cellule : tout ce qui est déjà téléchargé est en cache.")

def http_json(url):
    os.makedirs(CFG["CACHE"], exist_ok=True)
    path = os.path.join(CFG["CACHE"], hashlib.md5(url.encode()).hexdigest() + ".json")
    if os.path.exists(path):
        try:
            with open(path) as fh: return json.load(fh)
        except Exception:
            os.remove(path)                                # fichier corrompu : on le retélécharge
    r = _get(url, headers={"User-Agent": CFG["UA"]})
    time.sleep(0.25)                                   # ~4 requêtes/s, sous la limite SEC (10/s)
    if r.status_code == 404:
        js = None
    elif r.status_code == 200:
        js = r.json()
    else:
        raise RuntimeError(f"HTTP {r.status_code} pour {url}\n{r.text[:150]}\n"
                           "-> vérifie UA (vrai nom + vrai e-mail) ; si 403, attends ~10 min (blocage temporaire possible).")
    with open(path + ".tmp", "w") as fh: json.dump(js, fh)     # on ne met en cache que les réponses valides (200/404)
    os.replace(path + ".tmp", path)
    _tick()
    return js

def fred_csv(series_id):
    r = _get(f"https://fred.stlouisfed.org/graph/fredgraph.csv?id={series_id}")
    r.raise_for_status()
    df = pd.read_csv(io.StringIO(r.text)); df.columns = ["date", "v"]
    df["date"] = pd.to_datetime(df["date"]); df["v"] = pd.to_numeric(df["v"], errors="coerce")
    return df.set_index("date")["v"]

TAGS = dict(
    revenue=["Revenues", "RevenueFromContractWithCustomerExcludingAssessedTax", "SalesRevenueNet"],
    cogs=["CostOfRevenue", "CostOfGoodsAndServicesSold", "CostOfGoodsSold"],
    opinc=["OperatingIncomeLoss"],
    inventory=["InventoryNet"],
    receivables=["AccountsReceivableNetCurrent"],
)
DUR, INS = ["revenue", "cogs", "opinc"], ["inventory", "receivables"]

def frame_series(tags, period):
    out = None
    for tag in tags:
        js = http_json(f"https://data.sec.gov/api/xbrl/frames/us-gaap/{tag}/USD/{period}.json")
        if not js or not js.get("data"):
            continue
        s = pd.DataFrame(js["data"]).drop_duplicates("cik").set_index("cik")["val"].astype(float)
        out = s if out is None else out.combine_first(s)
    return out if out is not None else pd.Series(dtype=float)

def fetch_sic(cik):
    """Code SIC d'une entreprise (mis en cache sous forme minimale : les fichiers 'submissions' sont lourds)."""
    os.makedirs(CFG["CACHE"], exist_ok=True)
    path = os.path.join(CFG["CACHE"], f"sic_{int(cik)}.json")
    if os.path.exists(path):
        try:
            with open(path) as fh: v = json.load(fh)["sic"]
            return np.nan if v is None else v
        except Exception:
            os.remove(path)
    r = _get(f"https://data.sec.gov/submissions/CIK{int(cik):010d}.json", headers={"User-Agent": CFG["UA"]})
    time.sleep(0.25)
    if r.status_code == 200:
        try: v = int(r.json().get("sic"))
        except Exception: v = None
    elif r.status_code == 404: v = None
    else: raise RuntimeError(f"HTTP {r.status_code} pour le SIC de {cik} : {r.text[:150]}")
    with open(path + ".tmp", "w") as fh: json.dump({"sic": v}, fh)
    os.replace(path + ".tmp", path)
    _tick()
    return np.nan if v is None else v

def qlabel_to_idx(y, q): return (y - CFG["START_YEAR"]) * 4 + (q - 1)

def build_real_panel(cfg=CFG):
    store = {}; _t0 = time.time()
    for y in range(cfg["START_YEAR"], cfg["END_YEAR"] + 1):
        ann = {v: frame_series(TAGS[v], f"CY{y}") for v in DUR}
        for q in (1, 2, 3, 4):
            d = {v: frame_series(TAGS[v], f"CY{y}Q{q}") for v in DUR}
            d.update({v: frame_series(TAGS[v], f"CY{y}Q{q}I") for v in INS})
            store[(y, q)] = d
        for v in DUR:   # T4 = annuel - (T1+T2+T3) lorsque le T4 n'est pas publié seul
            derived = ann[v] - store[(y,1)][v] - store[(y,2)][v] - store[(y,3)][v]
            store[(y, 4)][v] = store[(y, 4)][v].combine_first(derived)
        print(f"\nEDGAR {y} ok ({time.time() - _t0:.0f}s)", end=" ", flush=True)
    parts = []
    for (y, q), d in store.items():
        df = pd.DataFrame(d); df["firm"] = df.index; df["q"] = qlabel_to_idx(y, q); parts.append(df)
    fin = pd.concat(parts, ignore_index=True).dropna(subset=["revenue", "cogs", "opinc"])
    fin = fin[fin["revenue"] > cfg["MIN_REV"]].copy()
    if cfg["SIC_RANGE"]:
        # MIN_QUARTERS s'applique aux trimestres UTILISABLES (inventaire et créances renseignés) : les autres lignes seraient écartées de toute façon
        keep = fin.dropna(subset=["inventory", "receivables"]).groupby("firm")["q"].count()
        keep = keep[keep >= cfg["MIN_QUARTERS"]].index
        lo, hi = cfg["SIC_RANGE"]; target = cfg.get("DRY_TARGET")
        if target: keep = pd.Index(np.random.default_rng(0).permutation(np.array(list(keep))))   # essai rapide : ordre aléatoire fixe
        print(f"\nCodes SIC à récupérer : jusqu'à {len(keep)} entreprises (un point = 25 requêtes)", flush=True)
        sic = {}; n_ok = 0
        for i, c in enumerate(keep):
            sic[c] = fetch_sic(c); v = sic[c]
            if v == v and lo <= v <= hi and not any(a <= v <= b for a, b in cfg["SIC_EXCLUDE"]): n_ok += 1
            if target and n_ok >= target: break                      # essai rapide : on s'arrête dès que l'échantillon est atteint
            if i % 200 == 0: print(f" SIC {i}/{len(keep)} ({time.time() - _t0:.0f}s)", end="", flush=True)
        sic = pd.Series(sic); ok = sic[(sic >= lo) & (sic <= hi)]
        for x0, x1 in cfg["SIC_EXCLUDE"]: ok = ok[~((ok >= x0) & (ok <= x1))]
        fin = fin[fin["firm"].isin(ok.index)].copy()
        fin["sic2"] = (fin["firm"].map(ok) // 100).astype(int)
    if "sic2" not in fin: fin["sic2"] = 0
    # ---- variables (proxies, voir limites dans le texte) ----
    fin["m"] = (fin["opinc"] / fin["revenue"]).clip(-0.5, 0.5)   # winsorisation fixe (pas de look-ahead)
    fin["stock"] = (fin["inventory"] / fin["cogs"].clip(lower=1) * 91).clip(0, 365)
    fin["delay"] = (fin["receivables"] / fin["revenue"] * 91).clip(0, 365)
    fin["rig"] = ((fin["revenue"] - fin["cogs"] - fin["opinc"]) / fin["revenue"]).clip(0, 1.5)  # ratio de charges d'exploitation
    # ---- choc énergie (YoY, trimestriel) ----
    en = fred_csv(cfg["ENERGY_SERIES"]); en = en.groupby(en.index.to_period("Q")).mean()
    en.index = [qlabel_to_idx(p.year, p.quarter) for p in en.index]
    g_en = np.log(en).diff(4).rename("g_en")
    return finish_real_panel(fin, g_en, cfg)

def finish_real_panel(fin, g_en, cfg=CFG):
    """Exposition et répercussion estimées sur t <= PRE_END_Q uniquement, puis chocs."""
    fin = fin.sort_values(["firm", "q"]).copy()
    fin["g_cogs"] = fin.groupby("firm")["cogs"].transform(lambda x: np.log(x).diff(4))
    fin["g_rev"] = fin.groupby("firm")["revenue"].transform(lambda x: np.log(x).diff(4))
    fin = fin.merge(g_en, left_on="q", right_index=True, how="left")
    pre = fin[fin["q"] <= cfg["PRE_END_Q"]].dropna(subset=["g_cogs", "g_rev", "g_en"])
    def slope(x, y):
        if len(x) < 12 or np.var(x) < 1e-12: return np.nan
        return np.cov(x, y)[0, 1] / np.var(x, ddof=1)
    est = []
    for f, d in pre.groupby("firm"):
        est.append(dict(firm=f, n=len(d), expo=slope(d["g_en"].values, d["g_cogs"].values),
                        pt=slope(d["g_cogs"].values, d["g_rev"].values)))
    est = pd.DataFrame(est).set_index("firm")
    est["expo_info"] = est["expo"].notna()                     # exposition réellement estimée (>= 12 obs.) ?
    sic_of = fin.groupby("firm")["sic2"].first(); est["sic2"] = est.index.map(sic_of)
    for c, lo, hi in [("expo", 0.0, 3.0), ("pt", 0.0, 1.5)]:
        raw = est[c].clip(lo, hi); gmed = raw.median()
        imed = raw.groupby(est["sic2"]).transform("median").fillna(gmed)
        imed = imed.where(raw.groupby(est["sic2"]).transform("count") >= 5, gmed)    # industrie trop petite -> médiane globale
        w = est["n"] / (est["n"] + 8.0)
        est[c] = (w * raw.fillna(imed) + (1 - w) * imed).clip(lo, hi)
    ind = {c: est.groupby("sic2")[c].median() for c in ("expo", "pt")}; gl = {c: est[c].median() for c in ("expo", "pt")}
    fin["expo"] = fin["firm"].map(est["expo"]); fin["expo"] = fin["expo"].fillna(fin["sic2"].map(ind["expo"])).fillna(gl["expo"])
    fin["pass"] = fin["firm"].map(est["pt"]);   fin["pass"] = fin["pass"].fillna(fin["sic2"].map(ind["pt"])).fillna(gl["pt"])
    fin["expo_info"] = fin["firm"].map(est["expo_info"]).fillna(False).astype(bool)
    fin["s"] = fin["expo"] * np.maximum(fin["g_en"].fillna(0.0), 0.0)
    return fin[["firm", "q", "m", "s", "stock", "delay", "rig", "pass", "expo", "expo_info"]].reset_index(drop=True)



# =====================================================================================
#  TABLEAUX, CIBLES, VARIABLES
# =====================================================================================
H, NL = CFG["H"], CFG["NL"]
XN = ["stock", "delay", "rig", "pass"]

def to_arrays(panel):
    firms = np.sort(panel["firm"].unique()); N = len(firms); T = int(panel["q"].max()) + 1
    fi = np.searchsorted(firms, panel["firm"].values); qi = panel["q"].values.astype(int)
    A = {}
    for c in ["m", "s"] + XN:
        a = np.full((N, T), np.nan); a[fi, qi] = panel[c].values; A[c] = a
    for c in XN:   # z-score transversal PAR TRIMESTRE : n'utilise que l'information du même trimestre
        mu = np.nanmean(A[c], axis=0, keepdims=True); sd = np.nanstd(A[c], axis=0, keepdims=True) + 1e-9
        A["z_" + c] = (A[c] - mu) / sd
    A["s0"] = np.nan_to_num(A["s"], nan=0.0)
    A["obs"] = ~np.isnan(A["m"]) & np.all([~np.isnan(A[c]) for c in XN], axis=0)
    A["N"], A["T"] = N, T
    return A

def make_targets(A, H=H):
    m = A["m"]; N, T = m.shape
    y = np.full((N, T), np.nan); R = np.full((N, T), np.nan)
    for t in range(T - H):
        fut = m[:, t+1:t+H+1]
        ok = ~np.isnan(m[:, t]) & ~np.isnan(fut).any(axis=1)
        y[ok, t] = m[ok, t+H] - m[ok, t]                     # variation de marge future
        rr = ok & (m[:, t] >= 0)
        R[rr, t] = (fut[rr].min(axis=1) < 0).astype(float)   # NOUVELLE rupture (marge < 0) dans les H trimestres
    return y, R

def lag_stack(a, k):
    out = np.zeros((a.shape[0], a.shape[1], k))
    for j in range(k):
        out[:, j:, j] = a[:, :a.shape[1] - j]
    return out

def sconv(q, kern):
    out = np.zeros_like(q)
    for j, w in enumerate(kern):
        if j < q.shape[1]: out[:, j:] += w * q[:, :q.shape[1] - j]
    return out

def damp_F(A, theta, flags, scale):
    """Pression cumulée prévue sur t..t+H-1, calculée avec l'information disponible en t
    (aucun choc futur : M_{t+k|t} propage la mémoire avec q futur = 0)."""
    rho, a0, a1, bs, bd, br, bp = theta
    Z = {k: np.nan_to_num(A["z_" + k]) for k in XN}
    absorb = np.maximum(0.0, a0 + a1 * Z["stock"]) * scale if flags["absorb"] else 0.0
    q = np.maximum(0.0, A["s0"] - absorb)
    lam = np.exp(np.clip(bs*Z["stock"] + bd*Z["delay"] + br*Z["rig"] + bp*Z["pass"], -5, 5)) if flags["lam"] else 1.0
    if not flags["mem"]: rho, Lk = 0.0, 0
    else: Lk = CFG["L"]
    K = torsional_kernel(Lk, flags["a"], CFG["TAU"])
    M = lfilter([1 - rho], [1.0, -rho], sconv(q, K), axis=1)
    Msum, Mprev = M.copy(), M
    for k in range(1, H):
        Kk = K[k:]
        d = sconv(q, Kk) if len(Kk) > 0 else 0.0
        Mk = rho * Mprev + (1 - rho) * d
        Msum += Mk; Mprev = Mk
    return lam * Msum

def design(A, model, theta=None, flags=None, scale=1.0):
    m = A["m"]; S = lag_stack(A["s0"], NL); Zs = [np.nan_to_num(A["z_" + k]) for k in XN]
    base = [np.nan_to_num(m)[:, :, None]]
    if model == "M0": return np.concatenate(base, axis=2)
    if model == "M1": return np.concatenate(base + [S], axis=2)
    if model == "M2":
        main = [z[:, :, None] for z in Zs]                 # effets principaux des variables opérationnelles
        inter = [S[:, :, j:j+1] * z[:, :, None] for z in Zs for j in range(NL)]
        return np.concatenate(base + [S] + main + inter, axis=2)
    if model == "M3_GB":
        return np.concatenate(base + [S] + [z[:, :, None] for z in Zs], axis=2)
    F = damp_F(A, theta, flags, scale)
    return np.concatenate(base + [F[:, :, None]], axis=2)

# ---------- test de causalité : réécrire le futur ne doit rien changer à l'origine t0 ----------
def causality_test(A, t0=45, seed=0):
    rng = np.random.default_rng(seed)
    B = {k: (v.copy() if isinstance(v, np.ndarray) else v) for k, v in A.items()}
    for c in ["m", "s", "s0"] + XN + ["z_" + c for c in XN]:
        B[c][:, t0+1:] = rng.normal(size=B[c][:, t0+1:].shape)
    th = [0.5, 0.3, 0.0, -0.2, 0.3, 0.2, -0.2]
    fl = dict(lam=True, mem=True, absorb=True, a=-0.5)
    res = {}
    for mod in ["M1", "M2", "DAMP"]:
        X1 = design(A, mod, th, fl, 0.1)[:, t0]; X2 = design(B, mod, th, fl, 0.1)[:, t0]
        res[mod] = bool(np.allclose(X1, X2))
    return res



# =====================================================================================
#  MODÈLES
# =====================================================================================
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.linear_model import LogisticRegression

DAMP_VARIANTS = {
    "DAMP":                 dict(lam=True,  mem=True,  absorb=True,  a=CFG["A_TORSION"]),
    "DAMP_sans_lambda":     dict(lam=False, mem=True,  absorb=True,  a=CFG["A_TORSION"]),
    "DAMP_sans_memoire":    dict(lam=True,  mem=False, absorb=True,  a=CFG["A_TORSION"]),
    "DAMP_sans_absorption": dict(lam=True,  mem=True,  absorb=False, a=CFG["A_TORSION"]),
    "DAMP_a0":              dict(lam=True,  mem=True,  absorb=True,  a=0.0),
}
BASELINES = ["M0", "M1", "M2", "M3_GB"]
ALL_MODELS = BASELINES + list(DAMP_VARIANTS)

def ridge_fit(X, y, alpha=1.0):
    mu, sd = X.mean(0), X.std(0) + 1e-12
    Xs = (X - mu) / sd; yb = y.mean()
    w = np.linalg.solve(Xs.T @ Xs + alpha * np.eye(X.shape[1]), Xs.T @ (y - yb))
    return dict(mu=mu, sd=sd, w=w, b=yb)

def ridge_predict(c, X): return c["b"] + ((X - c["mu"]) / c["sd"]) @ c["w"]

def fit_damp(A, y, rows, flags, scale):
    """Estime (rho, a0, a1, b_stock, b_delay, b_rig, b_pass) sur le train SEUL, en minimisant le
    MSE après recalibration linéaire [1, m_t, F]. Les blocs désactivés sont gelés."""
    bnds = [(0, .95), (0, 2), (-1, 1)] + [(-2, 2)] * 4
    if not flags["mem"]:    bnds[0] = (0, 0)
    if not flags["absorb"]: bnds[1] = (0, 0); bnds[2] = (0, 0)
    if not flags["lam"]:    bnds[3:] = [(0, 0)] * 4
    yy = y[rows]; var = yy.var()
    def loss(th):
        F = damp_F(A, th, flags, scale)
        X = np.column_stack([np.ones(rows.sum()), np.nan_to_num(A["m"])[rows], F[rows]])
        c, *_ = np.linalg.lstsq(X, yy, rcond=None)
        return np.mean((yy - X @ c) ** 2) / var
    best = None
    for st in ([0.5, 0.3, 0, 0, 0, 0, 0], [0.3, 0.8, 0.1, -.3, .3, .3, -.3]):
        st = [min(max(v, lo), hi) for v, (lo, hi) in zip(st, bnds)]
        res = minimize(loss, st, method="L-BFGS-B", bounds=bnds,
                       options=dict(maxiter=60, ftol=1e-10, eps=1e-4))
        if best is None or res.fun < best.fun: best = res
    th = best.x
    at_bound = [n for n, v, (lo, hi) in zip(["rho","a0","a1","b_stock","b_delay","b_rig","b_pass"], th, bnds)
                if hi > lo and (np.isclose(v, lo, atol=1e-3) or np.isclose(v, hi, atol=1e-3))]
    return th, at_bound

def fit_predict(model, A, y, rows_tr, scale):
    """Retourne (prédiction (N,T) de la variation de marge, theta, bornes)."""
    N, T = A["N"], A["T"]; theta = at_b = None
    if model in DAMP_VARIANTS:
        theta, at_b = fit_damp(A, y, rows_tr, DAMP_VARIANTS[model], scale)
        X = design(A, model, theta, DAMP_VARIANTS[model], scale)
    else:
        X = design(A, model)
    Xf = X.reshape(N * T, -1)
    r = rows_tr.reshape(-1)
    if model == "M3_GB":
        gb = HistGradientBoostingRegressor(max_iter=150, learning_rate=0.05, max_depth=4, random_state=CFG["SEED"])
        gb.fit(Xf[r], y.reshape(-1)[r]); pred = gb.predict(Xf)
    else:
        c = ridge_fit(Xf[r], y.reshape(-1)[r]); pred = ridge_predict(c, Xf)
    return pred.reshape(N, T), theta, at_b

def rupture_probs(pred_m, A, R, rows_tr_r, cols):
    """Probabilité de rupture = logistique sur le score -(marge prédite), calibrée sur le train."""
    score = -(np.nan_to_num(A["m"]) + pred_m)
    tr = rows_tr_r & ~np.isnan(R)
    if R[tr].sum() < 10: return np.full(score.shape, np.nan)
    lr = LogisticRegression(C=1e3).fit(score[tr][:, None], R[tr])
    p = np.full(score.shape, np.nan)
    p[:, cols] = lr.predict_proba(score[:, cols].reshape(-1, 1))[:, 1].reshape(score.shape[0], len(cols))
    return p



# =====================================================================================
#  WALK-FORWARD ET TESTS
# =====================================================================================
from sklearn.metrics import roc_auc_score, average_precision_score

def walk_forward_panel(A, models, verbose=True, max_refits=None):
    y, R = make_targets(A); N, T = A["N"], A["T"]
    preds = {m: np.full((N, T), np.nan) for m in models}
    probs = {m: np.full((N, T), np.nan) for m in models}
    plog = []
    for k_ref, t_r in enumerate(range(CFG["INIT"], T - H - 1, CFG["REFIT"])):
        if max_refits and k_ref >= max_refits: break
        tr_last = t_r - H - CFG["PUB_LAG"]            # cible réalisée ET publiée avant l'origine
        cols = np.arange(t_r + 1, min(t_r + CFG["REFIT"], T - H - 1) + 1)
        rows = A["obs"] & ~np.isnan(y); rows[:, :CFG["BURN"]] = False; rows[:, tr_last + 1:] = False
        pos = A["s0"][:, : tr_last + 1]; pos = pos[pos > 0]
        scale = pos.std() if len(pos) > 5 else 1.0
        for mod in models:
            pr, th, at_b = fit_predict(mod, A, y, rows, scale)
            preds[mod][:, cols] = pr[:, cols]
            probs[mod] = np.where(np.isnan(probs[mod]), rupture_probs(pr, A, R, rows, cols), probs[mod])
            if th is not None:
                plog.append(dict(t=t_r, modèle=mod, **dict(zip(["rho","a0","a1","b_stock","b_delay","b_rig","b_pass"], th)),
                                 bornes=",".join(at_b)))
        if verbose: print(f"origine {t_r} ok", end="; ")
    return preds, probs, pd.DataFrame(plog), y, R

def dm_test(d, h):
    """DM sur série d de différentiels de perte (moyenne par trimestre), HAC Bartlett h-1 retards,
    correction HLN, Student(n-1). d<0 => modèle 1 meilleur."""
    d = np.asarray(d); n = len(d); dbar = d.mean(); dc = d - dbar
    lrv = np.sum(dc * dc) / n
    for k in range(1, h):
        lrv += 2.0 * (1 - k / h) * np.sum(dc[k:] * dc[:-k]) / n
    lrv = max(lrv, 1e-18); dm = dbar / np.sqrt(lrv / n)
    hln = dm * np.sqrt((n + 1 - 2 * h + h * (h - 1) / n) / n)
    return hln, 2 * (1 - stats.t.cdf(abs(hln), df=n - 1))

def holm(p):
    p = np.asarray(p); o = np.argsort(p); m = len(p); adj = np.empty(m); run = 0.0
    for r_, i in enumerate(o):
        run = max(run, (m - r_) * p[i]); adj[i] = min(1.0, run)
    return adj

def evaluate(A, preds, probs, y, R, ref="DAMP", seed=0, drop_cols=None):
    models = list(preds); rng = np.random.default_rng(seed); N = A["N"]
    # ---------- marge : lignes communes à tous les modèles ----------
    E = A["obs"] & ~np.isnan(y)
    for m in models: E &= ~np.isnan(preds[m])
    if drop_cols is not None and len(drop_cols): E[:, drop_cols] = False
    fi, qi = np.where(E)
    err = {m: (y[E] - preds[m][E]) for m in models}
    met = pd.DataFrame([dict(modèle=m, n=E.sum(), RMSE=np.sqrt(np.mean(err[m]**2)), MAE=np.mean(np.abs(err[m])),
                             R2_vs_M0=1 - np.mean(err[m]**2) / np.mean(err["M0"]**2)) for m in models])
    rows = []
    for b in [m for m in models if m != ref]:
        d = err[ref]**2 - err[b]**2
        dq = pd.Series(d).groupby(qi).mean().values           # moyenne par trimestre d'origine
        stat, p = dm_test(dq, H)
        boots = np.empty(CFG["B_BOOT"])
        for k in range(CFG["B_BOOT"]):
            w = np.bincount(rng.integers(0, N, N), minlength=N)[fi]
            boots[k] = np.sum(w * d) / w.sum()
        lo, hi = np.percentile(boots, [2.5, 97.5])
        rows.append(dict(DAMP_vs=b, dMSE_e3=1e3*d.mean(), IC_bas_e3=1e3*lo, IC_haut_e3=1e3*hi, HLN=stat, p=p))
    T1 = pd.DataFrame(rows); T1["p_Holm"] = holm(T1["p"].values)
    T1["verdict"] = np.where(T1["p_Holm"] < .05, np.where(T1["dMSE_e3"] < 0, "DAMP meilleur", "DAMP moins bon"), "pas de différence")
    # ---------- ruptures : AUC, PR-AUC, Brier ----------
    E2 = A["obs"] & ~np.isnan(R)
    for m in models: E2 &= ~np.isnan(probs[m])
    if drop_cols is not None and len(drop_cols): E2[:, drop_cols] = False
    r = R[E2]; fi2 = np.where(E2)[0]; out = []; cl = {}
    if r.sum() >= 10 and r.sum() < len(r):
        for m in models:
            pm = probs[m][E2]
            out.append(dict(modèle=m, n=len(r), événements=int(r.sum()), AUC=roc_auc_score(r, pm),
                            PR_AUC=average_precision_score(r, pm), Brier=np.mean((pm - r)**2)))
        rows2 = []
        for b in [m for m in models if m != ref]:
            deltas = np.empty(CFG["B_BOOT"])
            for k in range(CFG["B_BOOT"]):
                w = np.bincount(rng.integers(0, N, N), minlength=N)[fi2].astype(float)
                if r[w > 0].sum() < 2 or r[w > 0].sum() == (w > 0).sum(): deltas[k] = np.nan; continue
                deltas[k] = roc_auc_score(r, probs[ref][E2], sample_weight=w) - roc_auc_score(r, probs[b][E2], sample_weight=w)
            deltas = deltas[~np.isnan(deltas)]
            lo, hi = np.percentile(deltas, [2.5, 97.5])
            p = min(1.0, 2 * min((deltas <= 0).mean(), (deltas >= 0).mean()) + 1 / len(deltas))
            rows2.append(dict(DAMP_vs=b, dAUC=roc_auc_score(r, probs[ref][E2]) - roc_auc_score(r, probs[b][E2]),
                              IC_bas=lo, IC_haut=hi, p=p))
        T2 = pd.DataFrame(rows2); T2["p_Holm"] = holm(T2["p"].values)
        T2["verdict"] = np.where(T2["p_Holm"] < .05, np.where(T2["dAUC"] > 0, "DAMP meilleur", "DAMP moins bon"), "pas de différence")
        AUC = pd.DataFrame(out)
    else:
        T2 = AUC = pd.DataFrame(); print("ATTENTION : moins de 10 ruptures exploitables -> test de rupture non interprétable")
    return met, T1, AUC, T2



# =====================================================================================
#  FALSIFICATION
# =====================================================================================
def permute_x_within_quarter(A, seed=0):
    """Mélange les 4 variables opérationnelles ENTRE entreprises, trimestre par trimestre."""
    rng = np.random.default_rng(seed); B = dict(A)
    for c in XN + ["z_" + c for c in XN]: B[c] = A[c].copy()
    N, T = A["N"], A["T"]
    for t in range(T):
        perm = rng.permutation(N)
        for c in XN + ["z_" + c for c in XN]: B[c][:, t] = A[c][perm, t]
    B["obs"] = ~np.isnan(B["m"]) & np.all([~np.isnan(B[c]) for c in XN], axis=0)
    return B

def shift_shocks(A, seed=0):
    """Décale circulairement la série de chocs de chaque entreprise (>= 8 trimestres)."""
    rng = np.random.default_rng(seed); B = dict(A)
    B["s"], B["s0"] = A["s"].copy(), A["s0"].copy(); T = A["T"]
    for i in range(A["N"]):
        k = int(rng.integers(8, T - 8)); B["s"][i] = np.roll(A["s"][i], k); B["s0"][i] = np.roll(A["s0"][i], k)
    return B



# =====================================================================================
#  ÉTAPES
# =====================================================================================
ALL_STAGES = ["data", "check", "freeze", "test"]

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""): h.update(chunk)
    return h.hexdigest()

def mode_name(args):
    return "synthetic" if args.synthetic else ("edgar_dry" if args.dry else "edgar")

def apply_mode(args):
    if args.synthetic:
        CFG.update(INIT=40, BURN=8, START_YEAR=2005)

def _decode_text(b):
    if b[:2] in (b"\xff\xfe", b"\xfe\xff"): return b.decode("utf-16")          # fichier créé par PowerShell avec ">"
    if b[:3] == b"\xef\xbb\xbf": return b.decode("utf-8-sig")                  # UTF-8 avec BOM (Bloc-notes)
    try: return b.decode("utf-8")
    except UnicodeDecodeError: return b.decode("cp1252", errors="replace")

def get_ua():
    import unicodedata
    raw = os.environ.get("SEC_UA", "")
    if not raw.strip() and os.path.exists("sec_user_agent.txt"):
        raw = _decode_text(open("sec_user_agent.txt", "rb").read())
    ua = " ".join(raw.replace("\ufeff", "").split())                                   # une seule ligne, espaces normalisés
    ua = unicodedata.normalize("NFKD", ua).encode("ascii", "ignore").decode("ascii")  # sans accents
    if not re.search(r"\S+@\S+\.\S+", ua):
        sys.exit("Identifiant SEC manquant ou invalide : crée sec_user_agent.txt avec UNE ligne « Prenom Nom ton.email@exemple.com » "
                 "(ou variable SEC_UA).")
    print("Identifiant SEC utilisé :", ua)
    return ua

def panel_path(args):
    f = f"panel_{mode_name(args)}.csv.gz"
    if not os.path.exists(f): sys.exit(f"{f} introuvable : lance d'abord l'étape 'data'.")
    return f

def load_panel_file(args):
    f = panel_path(args)
    return pd.read_csv(f), f

def covid_cols(T):
    """Origines dont la fenêtre [t+1, t+H] touche 2020 : 2019T1 .. 2020T4 (index relatifs à START_YEAR)."""
    base = (2020 - CFG["START_YEAR"]) * 4
    return np.array([c for c in range(max(base - CFG["H"], 0), min(base + 3, T - 1) + 1)])

# ------------------------------------------------------------------ étape 1 : data
def stage_data(args):
    f = f"panel_{mode_name(args)}.csv.gz"
    if args.synthetic:
        panel = simulate_panel(CFG["N_SIM"], CFG["T_SIM"], CFG["SIM_WORLD"], CFG["SEED"])
    else:
        CFG["UA"] = get_ua()
        CFG["DRY_TARGET"] = CFG["DRY_FIRMS"] if args.dry else None
        panel = build_real_panel(CFG)
        if args.dry:
            keep = np.random.default_rng(0).choice(panel["firm"].unique(), min(CFG["DRY_FIRMS"], panel["firm"].nunique()), replace=False)
            panel = panel[panel["firm"].isin(keep)].reset_index(drop=True)
    panel.to_csv(f, index=False, compression="gzip")
    print(f"\n\nPanel enregistré : {f}  |  lignes : {len(panel)}  |  entreprises : {panel['firm'].nunique()}  |  trimestres : {panel['q'].nunique()}")
    print(panel[["m", "s", "stock", "delay", "rig", "pass"]].describe().loc[["mean", "std", "min", "max"]].round(4).to_string())
    print("\n--- Entreprises par année ---")
    print(panel.groupby(panel["q"] // 4 + CFG["START_YEAR"])["firm"].nunique().to_string())
    life = panel.groupby("firm")["q"].count()
    print(f"\nTrimestres observés par entreprise : médiane {life.median():.0f} | min {life.min()} | max {life.max()}")
    if "expo_info" in panel:
        e = panel.groupby("firm")["expo_info"].first()
        print(f"Entreprises dont l'exposition a pu être estimée (>=12 obs. jusqu'en {CFG['START_YEAR'] + (CFG['PRE_END_Q'] + 1) // 4 - 1}T4) : {e.mean():.0%}")
        print("   (les autres reçoivent l'exposition médiane : si cette part est très faible, λ perd son pouvoir d'identification)")

# ------------------------------------------------------------------ étape 2 : check (aucune performance de modèle)
def stage_check(args):
    panel, f = load_panel_file(args)
    A = to_arrays(panel); Y, RUP = make_targets(A)
    ev = int(np.nansum(RUP)); nrup = int(np.sum(~np.isnan(RUP)))
    npres = int(np.sum(~np.isnan(A["m"]))); nobs = int(A["obs"].sum())
    print(f"Panel : {A['N']} entreprises x {A['T']} trimestres | lignes présentes : {npres} | exploitables (toutes variables renseignées) : {nobs} ({nobs / max(npres, 1):.0%})")
    print(f"Ruptures (nouvelle marge < 0 dans les {CFG['H']} trimestres) : {ev} événements sur {nrup} observations ({ev / max(nrup, 1):.1%})")
    test_start = CFG["INIT"] + 1
    ev_test = int(np.nansum(RUP[:, test_start:])); print(f"   dont dans la période de test (origines >= {test_start}) : {ev_test}")
    if ev_test < 200: print("   ATTENTION : moins de ~200 événements en test -> le test de rupture aura peu de puissance.")
    by_year = pd.Series(np.nansum(RUP, axis=0)).groupby(np.arange(A["T"]) // 4 + CFG["START_YEAR"]).sum()
    print("   événements par année d'origine :", by_year.astype(int).to_dict())
    cz = causality_test(A, t0=min(CFG["INIT"] + 3, A["T"] - 2))
    print("Test de causalité :", cz)
    if not all(cz.values()): sys.exit("FUITE DÉTECTÉE : ne pas continuer.")
    ncol = len(covid_cols(A["T"])); print(f"Origines exclues dans la robustesse Covid : {ncol} trimestres")
    print("\nContrôles terminés (aucune performance de modèle n'a été calculée).")

# ------------------------------------------------------------------ étape 3 : freeze
def stage_freeze(args):
    panel, f = load_panel_file(args)
    me = os.path.abspath(__file__)
    cfg = {k: v for k, v in CFG.items() if k not in ("UA",)}
    rec = dict(mode=mode_name(args), horodatage_utc=datetime.datetime.utcnow().isoformat() + "Z",
               script=os.path.basename(me), script_sha256=sha256_file(me),
               panel=f, panel_sha256=sha256_file(f), lignes=int(len(panel)), entreprises=int(panel["firm"].nunique()),
               config=cfg)
    out = f"protocole_fige_{mode_name(args)}.json"
    json.dump(rec, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=2, default=str)
    print(json.dumps({k: rec[k] for k in ("mode", "horodatage_utc", "script_sha256", "panel_sha256")}, indent=2))
    print(f"\nFichier écrit : {out}")
    print("À FAIRE MAINTENANT : téléverse sur OSF (ou Zenodo) ce fichier JSON + le script + une page décrivant les hypothèses.")
    print("Ne modifie plus ni le script ni le panel : 'test' vérifiera les empreintes.")

# ------------------------------------------------------------------ étape 4 : test
def stage_test(args):
    mode = mode_name(args); outdir = f"resultats_{mode}"
    f = panel_path(args)                      # les empreintes sont vérifiées AVANT toute lecture du panel
    if args.smoke:
        A = to_arrays(pd.read_csv(f)); t0 = time.time()
        pr, pb, pl, _, _ = walk_forward_panel(A, ALL_MODELS, verbose=False, max_refits=1)
        print("Essai technique (1 réestimation, AUCUNE performance affichée ni enregistrée) :")
        for m in ALL_MODELS: print(f"   {m:22s} prévisions produites : {int(np.sum(~np.isnan(pr[m])))}")
        print(f"   durée : {time.time() - t0:.0f}s | paramètres DAMP estimés sans erreur : {len(pl) > 0}")
        return
    if args.dry or args.synthetic:
        print("*" * 90 + f"\n  MODE {'ESSAI TECHNIQUE (--dry)' if args.dry else 'SIMULÉ'} : RÉSULTATS EXPLORATOIRES, NE PAS PUBLIER\n" + "*" * 90)
    else:
        fz = f"protocole_fige_{mode}.json"
        if not os.path.exists(fz): sys.exit("Protocole non gelé : lance d'abord 'freeze' (puis dépose le fichier sur OSF).")
        rec = json.load(open(fz, encoding="utf-8"))
        if rec["script_sha256"] != sha256_file(os.path.abspath(__file__)): sys.exit("Le script a changé depuis le gel : test refusé.")
        if rec["panel_sha256"] != sha256_file(f): sys.exit("Le panel a changé depuis le gel : test refusé.")
        print(f"Protocole gelé le {rec['horodatage_utc']} : empreintes vérifiées.")
    if os.path.exists(os.path.join(outdir, "principal_metrics.csv")) and not args.force:
        sys.exit(f"Des résultats existent déjà dans {outdir}/ : un second passage est refusé (--force pour passer outre ; ce sera journalisé).")
    os.makedirs(outdir, exist_ok=True)
    panel = pd.read_csv(f)
    A = to_arrays(panel)
    cz = causality_test(A, t0=min(CFG["INIT"] + 3, A["T"] - 2)); assert all(cz.values()), "FUITE DÉTECTÉE"
    t0 = time.time()
    PREDS, PROBS, PLOG, Y, RUP = walk_forward_panel(A, ALL_MODELS)
    print(f"\nWalk-forward terminé en {time.time() - t0:.0f}s")
    pd.set_option("display.width", 170, "display.float_format", lambda x: f"{x:.5f}")
    for label, tag, dc in [("PRINCIPAL (toutes les origines)", "principal", None),
                           ("ROBUSTESSE (origines Covid 2019T1-2020T4 exclues)", "robustesse_covid", covid_cols(A["T"]))]:
        MET, T_M, AUC, T_R = evaluate(A, PREDS, PROBS, Y, RUP, drop_cols=dc)
        print("\n" + "=" * 100 + f"\n{label}\n" + "=" * 100)
        print("\n--- Variation de marge sur 4 trimestres (hors-échantillon) ---\n", MET.to_string(index=False))
        print("\n--- DAMP vs autres (dMSE x1e3 ; négatif = DAMP meilleur ; DM-HAC+HLN ; bootstrap par entreprise ; Holm) ---\n", T_M.to_string(index=False))
        print("\n--- Ruptures de marge ---\n", AUC.to_string(index=False)); print(T_R.to_string(index=False))
        MET.to_csv(f"{outdir}/{tag}_metrics.csv", index=False); T_M.to_csv(f"{outdir}/{tag}_tests_marge.csv", index=False)
        AUC.to_csv(f"{outdir}/{tag}_auc.csv", index=False); T_R.to_csv(f"{outdir}/{tag}_tests_rupture.csv", index=False)
    # ---- falsification ----
    FM = ["M0", "M1", "M2", "DAMP", "DAMP_sans_lambda"]; rows = []
    for label, AA in [("réel", A), ("x permutés", permute_x_within_quarter(A)), ("chocs décalés", shift_shocks(A))]:
        if label == "réel": pr = {m: PREDS[m] for m in FM}; y_ = Y
        else: pr, _, _, y_, _ = walk_forward_panel(AA, FM, verbose=False)
        E = AA["obs"] & ~np.isnan(y_)
        for m in FM: E &= ~np.isnan(pr[m])
        mse = {m: np.mean((y_[E] - pr[m][E]) ** 2) for m in FM}
        rows.append(dict(scénario=label, **{f"gain_{m}_vs_M0_%": 100 * (1 - mse[m] / mse["M0"]) for m in FM[1:]}))
    FAL = pd.DataFrame(rows)
    print("\n=== Falsification : gain en MSE par rapport à M0 (%) ===")
    print("Lecture : x permutés -> les modèles qui utilisent x retombent au niveau de M1 ; chocs décalés -> M1 ~ 0.")
    print(FAL.to_string(index=False)); FAL.to_csv(f"{outdir}/falsification.csv", index=False)
    d = PLOG[PLOG["modèle"] == "DAMP"]
    print("\n=== Paramètres DAMP (médiane sur les réestimations) ===\n", d.drop(columns=["modèle", "t", "bornes"]).median().round(3).to_string())
    print("part des fits avec au moins un paramètre collé à une borne :", f"{(d['bornes'] != '').mean():.0%}")
    PLOG.to_csv(f"{outdir}/parametres.csv", index=False)
    jr = dict(horodatage_utc=datetime.datetime.utcnow().isoformat() + "Z", mode=mode, force=bool(args.force), duree_s=round(time.time() - t0))
    with open(f"{outdir}/journal.jsonl", "a", encoding="utf-8") as fj: fj.write(json.dumps(jr) + "\n")
    print(f"\nRésultats enregistrés dans {outdir}/")

# ------------------------------------------------------------------ main
def main(argv=None):
    ap = argparse.ArgumentParser(description="Protocole DAMP sur données d'entreprises")
    ap.add_argument("stage", choices=ALL_STAGES)
    ap.add_argument("--dry", action="store_true"); ap.add_argument("--synthetic", action="store_true")
    ap.add_argument("--force", action="store_true"); ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args(argv)
    apply_mode(args)
    {"data": stage_data, "check": stage_check, "freeze": stage_freeze, "test": stage_test}[args.stage](args)

if __name__ == "__main__":
    main()