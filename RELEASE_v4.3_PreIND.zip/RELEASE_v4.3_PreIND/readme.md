# DLMC v4.3 & MORPHEUS-HD: Unified Biophysical Modeling of Bivalent Therapeutics and Allele-Specific Dynamics in Huntington's Disease

[![Python](https://img.shields.io/badge/Python-3.9%2B-blue.svg)](https://www.python.org/)
[![License: CC BY 4.0](https://img.shields.io/badge/License-CC%20BY%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by/4.0/)
[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.22118740.svg)](https://doi.org/10.5281/zenodo.22118740)
[![ORCID](https://img.shields.io/badge/ORCID-0009--0009--6871--7693-green.svg)](https://orcid.org/0009-0009-6871-7693)
[![Status](https://img.shields.io/badge/Status-Pre--IND%20Package-emerald.svg)](#)

---

## 1. Project Overview

The **DLMC v4.3** (*Dynamic Log-Metric Correction*) and **MORPHEUS-HD v1.2** (*Multiscale Oxidation & Reaction-Diffusion Physics Engine*) framework provides a unified, multiscale biophysical and computational modeling platform designed to evaluate therapeutic interventions for Huntington's Disease (HD). 

Monogenic autosomal dominant CAG expansions in exon 1 of the *HTT* gene lead to toxic mutant huntingtin (mHTT) accumulation, severe striatal medium spiny neuron (MSN) atrophy, and corticostriatal uncoupling. Traditional non-selective pan-allelic gene silencing therapies (e.g., AMT-130 class) face severe safety and efficacy caps due to wild-type huntingtin (wtHTT) depletion, which induces metabolic deprivation and caps terminal neuronal survival at $\approx 79.96\%$.

This open-science repository contains the complete numerical pipeline, mathematical proofs, spatial tensor simulation engines, high-resolution figures, CSV metrics, and pre-clinical trial protocol documentation for a novel **sequential bivalent therapeutic strategy**:
1. **Stage 1 (Primary Intervention):** Stereotaxic allele-specific microRNA delivery (AAV5 vector targeting mHTT-specific SNPs like rs362307/rs362331), achieving 90% mutant knockdown while preserving 90% of neuroprotective native wtHTT.
2. **Stage 2 (Secondary Maintenance):** Oral maintenance relayer stimulating the TFEB/CLEAR autophagic clearance pathway ($\gamma_{\text{maint}} = +0.08\text{ yr}^{-1}$) initiated at age 50 to neutralize decadal somatic CAG drift and residual stochastic metabolic stress.

Additionally, parametric sensitivity analysis demonstrates a **critical bifurcation tipping point at age 60**, defining a strict clinical therapeutic window between ages 30 and 45.

---

## 2. Author Information

* **Lead Author & Biophysical Architect:** Mounir Djebassi (منير جباسي)
* **Affiliation:** Senior Scientific Software Engineer & Independent Researcher in Computational Biophysics, Department of Biophysical Research, Ferhat Abbas University of Setif 1, Algeria
* **Institutional Network:** International Network of Algerian Scientists (INAS)
* **ORCID:** [0009-0009-6871-7693](https://orcid.org/0009-0009-6871-7693)
* **Email:** `mounir.djebassi7306@etu.univ-setif.dz`
* **Zenodo Repository DOI:** [10.5281/zenodo.22118740](https://doi.org/10.5281/zenodo.22118740)

---

## 3. Repository Structure

```
RELEASE_v4.3_PreIND/
├── DLMC_Huntington_Master_v4.3_Bivalent_Protocol.ipynb # Jupyter Notebook containing complete simulation code
├── DLMC_v4.3_MORPHEUS_HD_Master_Monograph_EN.pdf       # Unified Master Scientific Monograph (English)
├── DLMC_v4.3_Monographie_Unifiee_OFFICIELLE.pdf       # Core Biophysical Monograph (French)
├── Rapport_Sertissage_Allelique_DLMC.pdf               # Allele-Specific Dynamics & Depletion Report
├── DLMC_v4.3_Prescription_Clinique.txt                 # Phase I/IIa Clinical Prescription Protocol File
├── README.md                                           # Repository Documentation (This file)
│
├── CSV_Data/
│   ├── DLMC_v4_1_Benchmark_Results.csv                 # Comparative benchmark across therapeutic strategies
│   ├── DLMC_v4_3_Delay_Analysis.csv                    # Bifurcation tipping point delay analysis data
│   ├── DLMC_v4.3_Bivalent_Protocol.csv                 # 80-year trajectory metrics for the bivalent protocol
│   └── DLMC_v4.3_Clinical_Translation_Metrics.csv      # Quantitative efficacy metrics for clinical translation
│
└── Figures/
    ├── DLMC_Advanced_Bio_3Panels.png                   # 3-Panel biophysical mechanisms and SDE dynamics
    ├── DLMC_Huntington_Analysis_v4.2.png               # Version 4.2 comparative survival curves
    ├── DLMC_Huntington_Bifurcation_2Panels.png         # Parametric bifurcation analysis at age 60
    ├── DLMC_v4_3_Bivalent_Simulation.png               # Bivalent protocol vs pan-allelic trajectory
    ├── MORPHEUS_HD_Spatial_Analysis.png                # MORPHEUS-HD 2D spatial clearance grid
    └── MORPHEUS_HD_Anisotropic_Analysis.png            # 45° Axonal tract anisotropic tensor diffusion map
```

---

## 4. Core Mathematical & Biophysical Equations

### 4.1 Coupled Stochastic Differential Equations (DLMC v4.3 SDE)
The single-cell temporal evolution of intracellular mutant ($[mHTT]$) and wild-type ($[wtHTT]$) huntingtin protein pools under metabolic noise is modeled using Itô Stochastic Differential Equations:

$$d[mHTT]_t = \left[ v_{\text{prod}}^{\text{mut}} \cdot \left(1 - E_m \cdot H(t - t_{\text{inj}})\right) - \gamma(t) \cdot [mHTT]_t - k_c \cdot [mHTT]_t \cdot [\text{Clearance}]_t \right] dt + \sigma_m \cdot dW_t^m$$

$$d[wtHTT]_t = \left[ v_{\text{prod}}^{\text{wt}} \cdot \left(1 - E_w \cdot H(t - t_{\text{inj}})\right) - \gamma_{\text{base}} \cdot [wtHTT]_t \right] dt + \sigma_w \cdot dW_t^w$$

*Where:*
* $H(t - t_{\text{inj}})$ is the Heaviside step function for stereotaxic delivery at age $t_{\text{inj}}$.
* $E_m = 0.90$ (90% allele-specific mutant silencing efficiency).
* $E_w = 0.10$ (10% wild-type knockdown, preserving 90% native $wtHTT$).
* $dW_t^m, dW_t^w$ represent independent Gaussian Wiener processes with metabolic noise intensities $\sigma_m, \sigma_w$.

### 4.2 Non-Linear Neuronal Viability Observable ($V_{\text{obs}}$)
Global cell integrity $V_{\text{obs}}(t) \in [0, 1]$ incorporates a quadratic penalty for aggregated mHTT and an asymmetric threshold penalty for wild-type depletion below 1.5 a.u.:

$$V_{\text{obs}}(t) = 1.0 - \left[ 0.40 \cdot [mHTT]_t^2 + 0.60 \cdot \max\left(0, 1.5 - [wtHTT]_t\right)^2 \right]$$

### 4.3 Anisotropic Spatial Diffusion Tensor (MORPHEUS-HD v1.2)
Spatial transport across $128 \times 128$ corticostriatal tissue geometries obeys the partial differential equation with directional tensor anisotropic diffusion:

$$\frac{\partial C}{\partial t} = \nabla \cdot (\mathbf{D} \cdot \nabla C) + R(C)$$

$$\mathbf{D} = \begin{pmatrix} D_{xx} & D_{xy} \\ D_{xy} & D_{yy} \end{pmatrix} = \begin{pmatrix} D_\parallel \cos^2\theta + D_\perp \sin^2\theta & (D_\parallel - D_\perp)\sin\theta\cos\theta \\ (D_\parallel - D_\perp)\sin\theta\cos\theta & D_\parallel \sin^2\theta + D_\perp \cos^2\theta \end{pmatrix}$$

*Where $\theta = 45^\circ$ represents primary fiber tract orientation, $D_\parallel = 0.40$ (axoplasmic transport), and $D_\perp = 0.02$ (transversal myelin restriction).*

---

## 5. Key Findings & Clinical Thresholds

| Therapeutic Metric | Natural History (Control) | Non-Selective RNAi (AMT-130 Class) | Delayed Monotherapy (Age 60) | **DLMC v4.3 Bivalent Protocol** |
| :--- | :---: | :---: | :---: | :---: |
| **Target mHTT Silencing** | $0\%$ | $75\%$ | $90\%$ | **$90\%$** |
| **Preserved Native wtHTT** | $100\%$ | $25\%$ (Depleted) | $90\%$ | **$90\%$** |
| **Secondary Autophagy Boost** | None | None | None | **$\gamma_{\text{maint}} = +0.08\text{ yr}^{-1}$** |
| **Terminal Viability (80 yrs)**| $42.10\%$ | $79.96\%$ | $82.00\%$ | **$98.05\%$** |
| **Striatal Atrophy (Volume Loss)**| $48.30\%$ | $22.10\%$ | $18.50\%$ | **$2.07\%$** |
| **Clinical Classification** | Fatal Cell Loss | Deprivation Risk | Irreversible Sequelae | **Resilient / Optimal** |

### Critical Clinical Insights:
1. **The Age-60 Bifurcation Tipping Point:** Intervening prior to age 45 maintains $\approx 100\%$ neuronal viability. Delaying initial treatment past age 60 triggers an irreversible transition where lysosomal degradation capacity fails to arrest mHTT aggregate propagation ($V_{\text{obs}}$ drops to $0.820$ at age 60 and $0.550$ at age 65).
2. **Optimal Therapeutic Window:** Presymptomatic or early symptomatic administration between **ages 30 and 45**.

---

## 6. Quickstart & Environment Setup

### Prerequisites
The codebase is written in Python 3.9+ and requires standard scientific libraries:

```bash
pip install numpy pandas matplotlib scipy jupyter
```

### Running the Simulation Pipeline
1. Clone the repository:
   ```bash
   git clone https://github.com/mounir-djebassi/DLMC-v4.3-MORPHEUS-HD.git
   cd DLMC-v4.3-MORPHEUS-HD
   ```
2. Launch the Jupyter Notebook environment:
   ```bash
   jupyter notebook DLMC_Huntington_Master_v4.3_Bivalent_Protocol.ipynb
   ```
3. Execute all cells to reproduce the stochastic differential simulations, spatial diffusion tensor integration, CSV exporting, and figure rendering.

---

## 7. Zenodo Archiving & Citation Instructions

If you use the DLMC v4.3 framework, MORPHEUS-HD engine, or clinical protocol datasets in your academic work or trial design, please cite this project as follows:

### BibTeX Entry
```bibtex
@article{Djebassi2026_DLMCv43,
  author       = {Mounir Djebassi},
  title        = {{DLMC v4.3 \& MORPHEUS-HD Unified Biophysical Modeling: Sequential Bivalent Therapeutics, Allele-Specific Dynamics, and Translational Protocol in Huntington's Disease}},
  journal      = {Department of Biophysical Research \& Clinical Translation, INAS Monograph Series},
  year         = {2026},
  publisher    = {Zenodo},
  doi          = {10.5281/zenodo.22118740},
  url          = {https://doi.org/10.5281/zenodo.22118740}
}
```

---

## 8. License & Open-Science Declaration

This project is licensed under the **Creative Commons Attribution 4.0 International License (CC BY 4.0)**. You are free to share, copy, modify, and build upon this research, provided appropriate credit is given to the author (**Mounir Djebassi**).