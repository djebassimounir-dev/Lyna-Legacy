#!/usr/bin/env python
# coding: utf-8

# In[13]:


import hashlib
from pathlib import Path
import numpy as np
import pandas as pd

# Working directory (unchanged)
WORK_DIR = Path(r"C:\Users\LENOVO\Desktop\EDPZ_Work\Rotmod_LTG")

# Official SPARC Table 1 (Lelli, McGaugh & Schombert 2016): must be present in WORK_DIR
TABLE1 = WORK_DIR / "SPARC_Lelli2016c.mrt.txt"
OUTPUT_CSV = WORK_DIR / "sparc_baryonic_masses.csv"
OUTPUT_HASH = WORK_DIR / "sparc_baryonic_masses.sha256"
OUTPUT_GAS_FRACTION = WORK_DIR / "sparc_gas_fraction.csv"

# Stellar mass-to-light ratio at 3.6 microns (SPARC standard value, McGaugh et al.)
UPSILON_STAR = 0.5

# Cosmological correction for helium (consistent with the factor already applied to Vgas
# in rotmod files, see Note 2 of SPARC documentation)
HE_CORRECTION = 1.33

NAMES = [
    "Galaxy",
    "T",
    "D",
    "e_D",
    "f_D",
    "Inc",
    "e_Inc",
    "L36",
    "e_L36",
    "Reff",
    "SBeff",
    "Rdisk",
    "SBdisk",
    "MHI",
    "RHI",
    "Vflat",
    "e_Vflat",
    "Q",
    "Ref",
]

def generate_masses_from_table1():
    if not TABLE1.exists():
        raise FileNotFoundError(
            f"SPARC Table 1 not found: {TABLE1}. Download SPARC_Lelli2016c.mrt from https://astroweb.case.edu/SPARC/"
        )
    
    df = pd.read_csv(TABLE1, skiprows=98, sep=r"\s+", header=None, names=NAMES, engine="python")
    df["Galaxy"] = df["Galaxy"].astype(str).str.strip()
    df = df.dropna(subset=["Galaxy", "L36", "MHI"])
    df = df[df["Galaxy"] != ""]
    
    # Baryonic mass = stellar mass (Upsilon x L[3.6]) + gas mass (M_HI x 1.33)
    df["Mgas"] = HE_CORRECTION * df["MHI"] * 1.0e9
    df["Mbar"] = UPSILON_STAR * df["L36"] * 1.0e9 + df["Mgas"]
    df["gas_fraction"] = df["Mgas"] / df["Mbar"]
    
    out = df[["Galaxy", "Mbar"]].copy()
    out = out[np.isfinite(out["Mbar"]) & (out["Mbar"] > 0)]
    
    out.to_csv(OUTPUT_CSV, index=False)
    df[["Galaxy", "gas_fraction"]].to_csv(OUTPUT_GAS_FRACTION, index=False)
    
    sha256_hash = hashlib.sha256(OUTPUT_CSV.read_bytes()).hexdigest()
    OUTPUT_HASH.write_text(sha256_hash)
    
    print(f"Generated file: {OUTPUT_CSV.name} ({len(out)} galaxies)")
    print(f"Upsilon_star = {UPSILON_STAR}, He correction = {HE_CORRECTION}")
    print(f"Mbar range: {out['Mbar'].min():.3e} -- {out['Mbar'].max():.3e} Msun")
    print(f"SHA-256: {sha256_hash}")

if __name__ == "__main__":
    generate_masses_from_table1()


# # UOEE-KAMAR - Reproducible Validation Pipeline
# 
# ## Objective
# 
# This notebook replaces exploratory, repeated cells, and hardcoded historic tables by evaluating a **global KAMAR law** on SPARC rotation curves with strict galaxy-level data splitting.
# 
# The UOEE layer is intentionally kept unoptimized here until a single equation, its units, and its bounds are fully frozen. This prevents target leakage or post-hoc variant selection on the test set.
# 
# **Publication Principle:** The figures and metrics generated herein only become citable following full execution against a documented baryonic mass table and archived output bundle.

# In[2]:


from __future__ import annotations

from dataclasses import asdict, dataclass
from hashlib import sha256
from pathlib import Path
import json
import platform
import sys

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
import sklearn
from scipy.optimize import least_squares
from sklearn.model_selection import GroupShuffleSplit

SEED = 20260921
RNG = np.random.default_rng(SEED)

# Local SPARC dataset directory
ROT_MOD_DIR = Path(r"C:\Users\LENOVO\Desktop\EDPZ_Work\Rotmod_LTG")

# Local computed and validated baryonic mass table for the 175 galaxies
MASS_CSV = Path(r"C:\Users\LENOVO\Desktop\EDPZ_Work\Rotmod_LTG\sparc_baryonic_masses.csv")

OUTPUT_DIR = Path(r"C:\Users\LENOVO\Documents\2026-09-21\ana\outputs\uoee_kamar_results")
TEST_FRACTION = 0.20
MSTAR_SOLAR = 1.0e10
UPSILON_DISK = 1.0
UPSILON_BULGE = 1.0

assert 0 < TEST_FRACTION < 1
assert ROT_MOD_DIR.is_dir(), f"SPARC directory not found: {ROT_MOD_DIR}"
print(f"Python {sys.version.split()[0]} | numpy {np.__version__} | scipy {scipy.__version__} | sklearn {sklearn.__version__}")
print(f"Rotation files found: {len(list(ROT_MOD_DIR.glob('*_rotmod.dat')))}")
print(f"Mass table: {MASS_CSV} ({'found' if MASS_CSV.exists() else 'MISSING'})")


# ## Data Contract
# 
# - Files matching `*_rotmod.dat` must contain columns: `r, Vobs, eV, Vgas, Vdisk, Vbulge`.
# - `Mbar` is derived from standard local processing linking optical luminosities and HI masses.
# - Every exclusion is recorded in a manifest file. Silent `try/except: pass` blocks are strictly prohibited.

# In[12]:


REQUIRED_COLUMNS = ["Galaxy", "Mbar"]

def canonical_name(name: str) -> str:
    """Normalize galaxy name identifiers without altering scientific content."""
    return str(name).strip().replace("_rotmod", "").upper()


def file_sha256(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_masses(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(
            "Missing mass table. Create a CSV containing 'Galaxy,Mbar' with Mbar in solar masses."
        )
    masses = pd.read_csv(path)
    if "galaxy" in masses.columns and "Galaxy" not in masses.columns:
        masses = masses.rename(columns={"galaxy": "Galaxy"})
    missing = set(REQUIRED_COLUMNS) - set(masses.columns)
    if missing:
        raise ValueError(f"Missing columns in {path.name}: {sorted(missing)}")
    masses = masses[["Galaxy", "Mbar"]].copy()
    masses["galaxy"] = masses["Galaxy"].map(canonical_name)
    masses = masses.drop(columns=["Galaxy"])
    masses["Mbar"] = pd.to_numeric(masses["Mbar"], errors="coerce")
    masses = masses.replace([np.inf, -np.inf], np.nan).dropna()
    masses = masses[masses["Mbar"] > 0]
    if masses.galaxy.duplicated().any():
        duplicates = masses.loc[masses.galaxy.duplicated(), "galaxy"].tolist()
        raise ValueError(f"Duplicate masses detected: {duplicates[:10]}")
    return masses


def read_rotmod(path: Path) -> pd.DataFrame:
    raw = np.loadtxt(path, comments="#")
    if raw.ndim != 2 or raw.shape[1] < 6:
        raise ValueError(f"Insufficient shape format ({raw.shape})")
    frame = pd.DataFrame(raw[:, :6], columns=["r", "Vobs", "eV", "Vgas", "Vdisk", "Vbulge"])
    frame["galaxy"] = canonical_name(path.stem)
    frame["source_file"] = path.name
    return frame


def baryonic_velocity(frame: pd.DataFrame) -> np.ndarray:
    """Vbar following SPARC convention: gas contribution can carry negative signs."""
    vbar_sq = (
        np.sign(frame["Vgas"].to_numpy()) * frame["Vgas"].to_numpy() ** 2
        + UPSILON_DISK * frame["Vdisk"].to_numpy() ** 2
        + UPSILON_BULGE * frame["Vbulge"].to_numpy() ** 2
    )
    return np.sqrt(np.clip(vbar_sq, 0.0, None))


def build_dataset(rotmod_dir: Path, masses: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    records, manifest = [], []
    mass_lookup = masses.set_index("galaxy")["Mbar"]
    for path in sorted(rotmod_dir.glob("*_rotmod.dat")) :
        galaxy = canonical_name(path.stem)
        item = {"galaxy": galaxy, "file": path.name, "sha256": file_sha256(path), "status": "excluded", "reason": ""}
        if galaxy not in mass_lookup.index:
            item["reason"] = "missing_Mbar"
            manifest.append(item)
            continue
        try:
            frame = read_rotmod(path)
        except Exception as exc:
            item["reason"] = f"read_error: {exc}"
            manifest.append(item)
            continue
        valid = np.isfinite(frame[["r", "Vobs", "eV", "Vgas", "Vdisk", "Vbulge"]]).all(axis=1)
        valid &= (frame["r"] > 0) & (frame["Vobs"] > 0) & (frame["eV"] > 0)
        frame = frame.loc[valid].copy()
        if len(frame) < 5:
            item["reason"] = "fewer_than_5_valid_points"
            manifest.append(item)
            continue
        frame["Mbar"] = float(mass_lookup[galaxy])
        frame["Vbar"] = baryonic_velocity(frame)
        frame["row_id"] = np.arange(len(frame))
        records.append(frame)
        item["status"] = "included"
        item["reason"] = ""
        item["n_points"] = len(frame)
        manifest.append(item)
    if not records:
        raise RuntimeError("No exploitable galaxies found after quality control checks.")
    return pd.concat(records, ignore_index=True), pd.DataFrame(manifest)


# In[4]:


masses = read_masses(MASS_CSV)
points, manifest = build_dataset(ROT_MOD_DIR, masses)

print(f"Included galaxies : {points.galaxy.nunique()}")
print(f"Included points   : {len(points)}")
print(f"Excluded galaxies : {(manifest.status == 'excluded').sum()}")
display(manifest.groupby(["status", "reason"], dropna=False).size().reset_index(name="n"))


# ## Models and Independent Split
# 
# Data partitioning is performed strictly at the galaxy level. KAMAR parameters are fitted exclusively on the training subset. The final test set remains locked until post-calibration evaluation.

# In[5]:


def kamar_velocity(r_kpc: np.ndarray, mbar_solar: np.ndarray, alpha: float, r0_star: float, gamma: float) -> np.ndarray:
    r0 = r0_star * np.power(mbar_solar / MSTAR_SOLAR, gamma)
    return alpha * np.sqrt(r_kpc / (r_kpc + r0))


def fit_kamar(train: pd.DataFrame) -> dict[str, float]:
    def residuals(theta: np.ndarray) -> np.ndarray:
        alpha, r0_star, gamma = np.exp(theta[0]), np.exp(theta[1]), theta[2]
        pred = kamar_velocity(train.r.to_numpy(), train.Mbar.to_numpy(), alpha, r0_star, gamma)
        return (train.Vobs.to_numpy() - pred) / train.eV.to_numpy()

    result = least_squares(
        residuals,
        x0=np.array([np.log(150.0), np.log(3.0), 0.0]),
        bounds=(np.array([np.log(20.0), np.log(0.01), -3.0]), np.array([np.log(500.0), np.log(100.0), 3.0])),
        method="trf",
    )
    if not result.success:
        raise RuntimeError(f"Calibration failed: {result.message}")
    return {"alpha_km_s": float(np.exp(result.x[0])), "r0_star_kpc": float(np.exp(result.x[1])), "gamma": float(result.x[2]), "cost": float(result.cost)}


galaxies = np.array(sorted(points.galaxy.unique()))
splitter = GroupShuffleSplit(n_splits=1, test_size=TEST_FRACTION, random_state=SEED)
train_idx, test_idx = next(splitter.split(galaxies, groups=galaxies))
train_galaxies, test_galaxies = set(galaxies[train_idx]), set(galaxies[test_idx])
train = points[points.galaxy.isin(train_galaxies)].copy()
test = points[points.galaxy.isin(test_galaxies)].copy()
assert not (set(train.galaxy) & set(test.galaxy))

theta = fit_kamar(train)
print("Parameters calibrated exclusively on training set:")
display(pd.DataFrame([theta]))
print(f"Train subset: {train.galaxy.nunique()} galaxies, {len(train)} points")
print(f"Test subset : {test.galaxy.nunique()} galaxies, {len(test)} points")


# In[6]:


def evaluate(data: pd.DataFrame, params: dict[str, float]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    out = data.copy()
    out["Vnewton"] = out["Vbar"]
    out["Vkamar"] = kamar_velocity(out.r.to_numpy(), out.Mbar.to_numpy(), params["alpha_km_s"], params["r0_star_kpc"], params["gamma"])
    rows = []
    for model, column in [("Newton_baryonic", "Vnewton"), ("KAMAR", "Vkamar")]:
        residual = out.Vobs - out[column]
        tmp = out[["galaxy"]].copy()
        tmp["residual"] = residual
        per_galaxy = tmp.groupby("galaxy").residual.agg(lambda x: float(np.sqrt(np.mean(np.square(x))))).rename("rmse")
        chi2 = float(np.sum(np.square(residual / out.eV)))
        rows.append({
            "model": model,
            "n_galaxies": int(out.galaxy.nunique()),
            "n_points": int(len(out)),
            "rmse_global_km_s": float(np.sqrt(np.mean(np.square(residual)))),
            "rmse_median_by_galaxy_km_s": float(per_galaxy.median()),
            "mae_km_s": float(np.mean(np.abs(residual))),
            "mean_residual_km_s": float(np.mean(residual)),
            "chi2_reduced": chi2 / max(1, len(out) - 3),
        })
        out[f"residual_{model}"] = residual
    per_galaxy = out.groupby("galaxy").agg(Mbar=("Mbar", "first"), n=("row_id", "size"), rmse_newton=("residual_Newton_baryonic", lambda x: float(np.sqrt(np.mean(np.square(x)))),), rmse_kamar=("residual_KAMAR", lambda x: float(np.sqrt(np.mean(np.square(x)))),)).reset_index()
    return out, pd.DataFrame(rows), per_galaxy


test_points, test_metrics, per_galaxy = evaluate(test, theta)
display(test_metrics)
display(per_galaxy.sort_values("rmse_kamar", ascending=False).head(10))


# In[7]:


def bootstrap_median_rmse(per_galaxy: pd.DataFrame, column: str, n_boot: int = 2000) -> tuple[float, float]:
    values = per_galaxy[column].to_numpy()
    draws = np.array([np.median(RNG.choice(values, size=len(values), replace=True)) for _ in range(n_boot)])
    return tuple(np.quantile(draws, [0.025, 0.975]))

ci_newton = bootstrap_median_rmse(per_galaxy, "rmse_newton")
ci_kamar = bootstrap_median_rmse(per_galaxy, "rmse_kamar")
print(f"95% CI median RMSE Newton: {ci_newton}")
print(f"95% CI median RMSE KAMAR : {ci_kamar}")

fig, axes = plt.subplots(1, 3, figsize=(16, 4.5), constrained_layout=True)
limit = max(test_points.Vobs.max(), test_points.Vkamar.max())
axes[0].scatter(test_points.Vobs, test_points.Vkamar, s=9, alpha=0.45)
axes[0].plot([0, limit], [0, limit], "k--", lw=1)
axes[0].set(xlabel="Vobs (km/s)", ylabel="Vkamar (km/s)", title="Final Test: Prediction vs Observation")
axes[1].scatter(test_points.r, test_points.residual_KAMAR, s=9, alpha=0.45)
axes[1].axhline(0, color="k", ls="--", lw=1)
axes[1].set(xlabel="r (kpc)", ylabel="Vobs - Vkamar (km/s)", title="Radial Residuals")
axes[2].scatter(np.log10(per_galaxy.Mbar), per_galaxy.rmse_kamar - per_galaxy.rmse_newton, s=22, alpha=0.7)
axes[2].axhline(0, color="k", ls="--", lw=1)
axes[2].set(xlabel="log10(Mbar / Msun)", ylabel="RMSE KAMAR - Newton", title="Gain per Mass scale")
plt.show()


# In[8]:


# Figure 2 : residus vs rayon normalise, masse baryonique, fraction de gaz
gas_fraction = pd.read_csv(MASS_CSV.parent / "sparc_gas_fraction.csv")
gas_fraction["galaxy"] = gas_fraction["Galaxy"].astype(str).str.strip().str.upper()

tp2 = test_points.copy()
tp2["r_norm"] = tp2.groupby("galaxy")["r"].transform(lambda x: x / x.max())
tp2 = tp2.merge(gas_fraction[["galaxy", "gas_fraction"]], on="galaxy", how="left")

fig2, axes2 = plt.subplots(1, 3, figsize=(16, 4.5), constrained_layout=True)
axes2[0].scatter(tp2.r_norm, tp2.residual_KAMAR, s=10, alpha=0.4, color="darkorange")
axes2[0].axhline(0, color="k", ls="--", lw=1)
axes2[0].set(xlabel="Normalized radius r / r_max", ylabel="Vobs - Vkamar (km/s)",
             title="(a) Residuals vs Normalized Radius")

axes2[1].scatter(np.log10(tp2.Mbar), tp2.residual_KAMAR, s=10, alpha=0.4, color="seagreen")
axes2[1].axhline(0, color="k", ls="--", lw=1)
axes2[1].set(xlabel="log10(Mbar / Msun)", ylabel="Vobs - Vkamar (km/s)",
             title="(b) Residuals vs Baryonic Mass")

axes2[2].scatter(tp2.gas_fraction, tp2.residual_KAMAR, s=10, alpha=0.4, color="steelblue")
axes2[2].axhline(0, color="k", ls="--", lw=1)
axes2[2].set(xlabel="Gas fraction Mgas / Mbar", ylabel="Vobs - Vkamar (km/s)",
             title="(c) Residuals vs Gas Fraction")
fig2.suptitle("Figure 2: Residual Diagnostics (Test Set, KAMAR)", fontweight="bold")
plt.show()


# In[9]:


# Figure 3 : courbes representatives (meilleur, median, pire cas, naine typique)
per_galaxy_sorted = per_galaxy.sort_values("rmse_kamar")
n = len(per_galaxy_sorted)
picks = {
    "Best fit": per_galaxy_sorted.iloc[0]["galaxy"],
    "Median fit": per_galaxy_sorted.iloc[n // 2]["galaxy"],
    "Difficult case (worst)": per_galaxy_sorted.iloc[-1]["galaxy"],
    "Typical dwarf (low mass)": per_galaxy_sorted.sort_values("Mbar").iloc[0]["galaxy"],
}

fig3, axes3 = plt.subplots(2, 2, figsize=(13, 10), constrained_layout=True)
for ax, (label, gal) in zip(axes3.flat, picks.items()):
    sub = test_points[test_points.galaxy == gal].sort_values("r")
    ax.errorbar(sub.r, sub.Vobs, yerr=sub.eV, fmt="o", color="black", ms=4, capsize=2, label="Observed")
    ax.plot(sub.r, sub.Vkamar, "-", color="red", lw=2, label="UOEE-KAMAR")
    ax.plot(sub.r, sub.Vnewton, "--", color="blue", lw=2, label="Newtonian baryonic")
    ax.set(xlabel="Radius (kpc)", ylabel="Velocity (km/s)", title=f"{label}: {gal}")
    ax.legend(fontsize=8)
fig3.suptitle("Figure 3: Representative Rotation Curves (Test Set)", fontweight="bold")
plt.show()
print("Galaxies selectionnees :", picks)


# ## Result Archiving
# 
# This cell exports data tables, manifests, parameters, configuration snapshots, and figures. Manuscript tables must be dynamically built from these files and never hardcoded manually.

# ## UOEE Extension - Pre-registration Rule
# 
# Prior to introducing any UOEE-KAMAR extension, duplicate this notebook and explicitly state in the manuscript:
# 
# 1. The complete mathematical formulation and physical units;
# 2. Additional parameters and their boundary constraints;
# 3. Expected theoretical predictions relative to minimal KAMAR;
# 4. Preservation of the identical train/test split without re-consulting the final test set;
# 5. Clear success and failure acceptance criteria.
# 
# Any extension selected post-hoc after inspecting test set residuals remains strictly exploratory and must be labeled accordingly.

# In[10]:


OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
config = {
    "seed": SEED,
    "rotmod_dir": str(ROT_MOD_DIR),
    "mass_csv": str(MASS_CSV),
    "mass_csv_sha256": file_sha256(MASS_CSV),
    "test_fraction": TEST_FRACTION,
    "Mstar_solar": MSTAR_SOLAR,
    "upsilon_disk": UPSILON_DISK,
    "upsilon_bulge": UPSILON_BULGE,
    "parameters_train_only": theta,
    "python": sys.version,
    "platform": platform.platform(),
}
(OUTPUT_DIR / "run_config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")
manifest.to_csv(OUTPUT_DIR / "data_manifest.csv", index=False)
test_points.to_csv(OUTPUT_DIR / "test_points.csv", index=False)
per_galaxy.to_csv(OUTPUT_DIR / "test_per_galaxy.csv", index=False)
test_metrics.assign(ci95_median_rmse=[str(ci_newton), str(ci_kamar)]).to_csv(OUTPUT_DIR / "test_metrics.csv", index=False)

fig.savefig(OUTPUT_DIR / "test_diagnostics.png", dpi=220, bbox_inches="tight")
print(f"Outputs successfully written to: {OUTPUT_DIR}")


# In[11]:


# Archivage des Figures 2 et 3 + tables reelles
fig2.savefig(OUTPUT_DIR / "Figure2_Residual_Diagnostics.png", dpi=220, bbox_inches="tight")
fig3.savefig(OUTPUT_DIR / "Figure3_Representative_Curves.png", dpi=220, bbox_inches="tight")
print(f"Figures 2 et 3 sauvegardees dans : {OUTPUT_DIR}")

